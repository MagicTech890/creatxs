﻿namespace Core.Models
{
    public class Merchant : ApplicationUser
    {
        public string StoreName { get; set; }
    }
}
