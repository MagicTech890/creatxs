﻿namespace Core.Models
{
    public class EndUser : ApplicationUser
    {

    }
}
