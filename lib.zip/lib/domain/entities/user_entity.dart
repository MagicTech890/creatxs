class UserEntity {
  final String id;
  final String email;
  final String? phoneNumber;
  final String? name;
  final String? storeName;
  final bool isMerchant;
  final String? token;

  UserEntity({
    required this.id,
    required this.email,
    this.phoneNumber,
    this.name,
    this.storeName,
    this.isMerchant = false,
    this.token,
  });
}
