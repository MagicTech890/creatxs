import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:dio/dio.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/services/auth_service.dart';
import 'core/error/failures.dart';
import 'core/network/network_info.dart';
import 'core/config/app_config.dart';
import 'core/network/dio_client.dart';
import 'core/routes/app_router.dart';
import 'core/theme/app_theme.dart';

import 'features/auth/presentation/bloc/auth_bloc.dart';
import 'features/auth/domain/repositories/auth_repository.dart';
import 'features/auth/data/repositories/auth_repository_impl.dart';
import 'features/auth/data/datasources/auth_remote_datasource.dart';

import 'core/providers/auth_provider.dart';
import 'core/network/api_service.dart';

// AuthServiceProvider is now imported from auth_provider.dart

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  AppConfig().setEnvironment(Environment.development);
  await setupDependencies();
  runApp(const ProviderScope(child: MyApp()));
}

Future<void> setupDependencies() async {
  final getIt = GetIt.instance;
  final sharedPreferences = await SharedPreferences.getInstance();
  getIt.registerSingleton<SharedPreferences>(sharedPreferences);

  final dio = Dio();
  dio.options = BaseOptions(
    baseUrl: AppConfig().apiBaseUrl,
    connectTimeout: const Duration(seconds: 30),
    receiveTimeout: const Duration(seconds: 30),
    sendTimeout: const Duration(seconds: 30),
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
  );
  getIt.registerSingleton<Dio>(dio);

  final networkInfo = NetworkInfoImpl(Connectivity());
  getIt.registerSingleton<NetworkInfo>(networkInfo);

  final remoteDataSource = AuthRemoteDataSourceImpl(dio);
  getIt.registerSingleton<AuthRemoteDataSource>(remoteDataSource);

  final dioClient = DioClient(dio: dio, prefs: sharedPreferences);
  getIt.registerSingleton<DioClient>(dioClient);

  final authRepository = AuthRepositoryImpl(
    dioClient: dioClient,
    prefs: sharedPreferences,
  );
  getIt.registerSingleton<AuthRepository>(authRepository);
}

class MyApp extends ConsumerWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<AuthBloc>(
          create: (context) => AuthBloc(
            authRepository: GetIt.instance<AuthRepository>(),
          )..add(CheckAuthStatus()),
        ),
      ],
      child: MaterialApp(
        title: 'CreatXS',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.system,
        locale: const Locale('ar', 'SA'),
        supportedLocales: const [
          Locale('ar', 'SA'),
          Locale('en', 'US'),
        ],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        onGenerateRoute: AppRouter.generateRoute,
        initialRoute: AppRouter.login,
        builder: (context, child) {
          return MediaQuery(
            data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
            child: Directionality(
              textDirection: TextDirection.rtl,
              child: child!,
            ),
          );
        },
      ),
    );
  }
}
