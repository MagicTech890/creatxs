import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import '../../../../core/network/api_client.dart';
import '../../../../core/config/app_config.dart';

class ApiTestPage extends StatefulWidget {
  const ApiTestPage({super.key});

  @override
  State<ApiTestPage> createState() => _ApiTestPageState();
}

class _ApiTestPageState extends State<ApiTestPage> {
  final ApiClient _apiClient = GetIt.instance<ApiClient>();
  final AppConfig _appConfig = AppConfig();
  bool _isLoading = false;
  String _result = 'اضغط على الزر لاختبار الاتصال بالـ API';
  dynamic _weatherData;

  Future<void> _testApiConnection() async {
    setState(() {
      _isLoading = true;
      _result = 'جارِ الاتصال بالـ API...';
      _weatherData = null;
    });

    try {
      final response = await _apiClient.getWeatherForecast();
      setState(() {
        _isLoading = false;
        _result = 'تم الاتصال بنجاح!';
        _weatherData = response;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _result = 'فشل الاتصال: ${e.toString()}';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('اختبار الاتصال بالـ API'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'عنوان الـ API الحالي:',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _appConfig.apiBaseUrl,
                        style: const TextStyle(
                          fontFamily: 'Consolas',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'النقطة النهائية المستهدفة:',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        '/weatherforecast',
                        style: TextStyle(
                          fontFamily: 'Consolas',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _isLoading ? null : _testApiConnection,
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child:
                      Text(_isLoading ? 'جارِ الاختبار...' : 'اختبار الاتصال'),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'النتيجة:',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 8),
              Text(_result),
              const SizedBox(height: 16),
              if (_weatherData != null) ...[
                Text(
                  'بيانات الطقس:',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 8),
                Container(
                  height: 200,
                  child: SingleChildScrollView(
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Text(
                          _weatherData.toString(),
                          style: const TextStyle(fontFamily: 'Consolas'),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
