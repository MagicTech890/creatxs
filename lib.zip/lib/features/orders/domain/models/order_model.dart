import 'package:json_annotation/json_annotation.dart';

part 'order_model.g.dart';

@JsonSerializable()
class OrderModel {
  final String id;
  final String storeId;
  final String? customerId;
  final List<OrderItem> items;
  final OrderStatus status;
  final PaymentStatus paymentStatus;
  final PaymentMethod paymentMethod;
  final ShippingMethod shippingMethod;
  final Address? shippingAddress;
  final Address? billingAddress;
  final double subtotal;
  final double shippingCost;
  final double tax;
  final double total;
  final String? note;
  final DateTime createdAt;
  final DateTime updatedAt;
  final Map<String, dynamic>? metadata;

  OrderModel({
    required this.id,
    required this.storeId,
    this.customerId,
    required this.items,
    this.status = OrderStatus.pending,
    this.paymentStatus = PaymentStatus.pending,
    required this.paymentMethod,
    required this.shippingMethod,
    this.shippingAddress,
    this.billingAddress,
    required this.subtotal,
    required this.shippingCost,
    required this.tax,
    required this.total,
    this.note,
    required this.createdAt,
    required this.updatedAt,
    this.metadata,
  });

  factory OrderModel.fromJson(Map<String, dynamic> json) =>
      _$OrderModelFromJson(json);

  Map<String, dynamic> toJson() => _$OrderModelToJson(this);

  OrderModel copyWith({
    String? id,
    String? storeId,
    String? customerId,
    List<OrderItem>? items,
    OrderStatus? status,
    PaymentStatus? paymentStatus,
    PaymentMethod? paymentMethod,
    ShippingMethod? shippingMethod,
    Address? shippingAddress,
    Address? billingAddress,
    double? subtotal,
    double? shippingCost,
    double? tax,
    double? total,
    String? note,
    DateTime? createdAt,
    DateTime? updatedAt,
    Map<String, dynamic>? metadata,
  }) {
    return OrderModel(
      id: id ?? this.id,
      storeId: storeId ?? this.storeId,
      customerId: customerId ?? this.customerId,
      items: items ?? this.items,
      status: status ?? this.status,
      paymentStatus: paymentStatus ?? this.paymentStatus,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      shippingMethod: shippingMethod ?? this.shippingMethod,
      shippingAddress: shippingAddress ?? this.shippingAddress,
      billingAddress: billingAddress ?? this.billingAddress,
      subtotal: subtotal ?? this.subtotal,
      shippingCost: shippingCost ?? this.shippingCost,
      tax: tax ?? this.tax,
      total: total ?? this.total,
      note: note ?? this.note,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      metadata: metadata ?? this.metadata,
    );
  }
}

@JsonSerializable()
class OrderItem {
  final String productId;
  final String name;
  final String? variantId;
  final Map<String, dynamic>? options;
  final double price;
  final int quantity;
  final double total;

  OrderItem({
    required this.productId,
    required this.name,
    this.variantId,
    this.options,
    required this.price,
    required this.quantity,
    required this.total,
  });

  factory OrderItem.fromJson(Map<String, dynamic> json) =>
      _$OrderItemFromJson(json);

  Map<String, dynamic> toJson() => _$OrderItemToJson(this);
}

@JsonSerializable()
class Address {
  final String name;
  final String phone;
  final String address1;
  final String? address2;
  final String city;
  final String state;
  final String country;
  final String postalCode;

  Address({
    required this.name,
    required this.phone,
    required this.address1,
    this.address2,
    required this.city,
    required this.state,
    required this.country,
    required this.postalCode,
  });

  factory Address.fromJson(Map<String, dynamic> json) =>
      _$AddressFromJson(json);

  Map<String, dynamic> toJson() => _$AddressToJson(this);
}

enum OrderStatus {
  @JsonValue('pending')
  pending,
  @JsonValue('confirmed')
  confirmed,
  @JsonValue('processing')
  processing,
  @JsonValue('ready')
  ready,
  @JsonValue('in_delivery')
  inDelivery,
  @JsonValue('delivered')
  delivered,
  @JsonValue('completed')
  completed,
  @JsonValue('cancelled')
  cancelled,
}

enum PaymentStatus {
  @JsonValue('pending')
  pending,
  @JsonValue('paid')
  paid,
  @JsonValue('failed')
  failed,
  @JsonValue('refunded')
  refunded,
}

enum PaymentMethod {
  @JsonValue('cash')
  cash,
  @JsonValue('card')
  card,
  @JsonValue('bank_transfer')
  bankTransfer,
}

enum ShippingMethod {
  @JsonValue('standard')
  standard,
  @JsonValue('express')
  express,
  @JsonValue('pickup')
  pickup,
}
