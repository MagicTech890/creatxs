import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../core/theme/app_theme.dart';

class ProductsPage extends StatefulWidget {
  const ProductsPage({super.key});

  @override
  State<ProductsPage> createState() => _ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  final TextEditingController _searchController = TextEditingController();
  String _selectedCategory = 'الكل';
  String _selectedStatus = 'الكل';

  final List<String> _categories = [
    'الكل',
    'الملابس',
    'الأحذية',
    'الإكسسوارات',
    'الإلكترونيات',
    'المنزل والحديقة',
  ];

  final List<String> _statuses = [
    'الكل',
    'نشط',
    'مسودة',
    'نفد من المخزون',
    'أرشيف',
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(),
          _buildFilters(),
          Expanded(
            child: _buildProductList(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // TODO: Navigate to add product page
        },
        backgroundColor: AppTheme.primaryColor,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'البحث عن منتج...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey.shade100,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 0,
                ),
              ),
              onChanged: (value) {
                // TODO: Implement search
                setState(() {});
              },
            ),
          ),
          const SizedBox(width: 16),
          PopupMenuButton(
            icon: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.more_vert),
            ),
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'export',
                child: Row(
                  children: [
                    Icon(Icons.download),
                    SizedBox(width: 8),
                    Text('تصدير المنتجات'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'import',
                child: Row(
                  children: [
                    Icon(Icons.upload),
                    SizedBox(width: 8),
                    Text('استيراد المنتجات'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'bulk_edit',
                child: Row(
                  children: [
                    Icon(Icons.edit),
                    SizedBox(width: 8),
                    Text('تعديل متعدد'),
                  ],
                ),
              ),
            ],
            onSelected: (value) {
              // TODO: Handle menu selection
            },
          ),
        ],
      ),
    );
  }

  Widget _buildFilters() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _buildCategoryFilter(),
            const SizedBox(width: 12),
            _buildStatusFilter(),
            const SizedBox(width: 12),
            _buildSortButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryFilter() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _selectedCategory,
          items: _categories.map((category) {
            return DropdownMenuItem<String>(
              value: category,
              child: Text(
                category,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                ),
              ),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedCategory = value!;
            });
          },
          icon: const Icon(Icons.keyboard_arrow_down),
          hint: Text(
            'التصنيف',
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusFilter() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _selectedStatus,
          items: _statuses.map((status) {
            return DropdownMenuItem<String>(
              value: status,
              child: Text(
                status,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                ),
              ),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedStatus = value!;
            });
          },
          icon: const Icon(Icons.keyboard_arrow_down),
          hint: Text(
            'الحالة',
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSortButton() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: [
          const Icon(Icons.sort, size: 20),
          const SizedBox(width: 4),
          Text(
            'ترتيب',
            style: GoogleFonts.poppins(
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProductList() {
    final products = _getDummyProducts();

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'المنتجات (${products.length})',
                style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              TextButton.icon(
                onPressed: () {
                  // TODO: Navigate to products grid view
                },
                icon: const Icon(Icons.grid_view),
                label: Text(
                  'عرض الشبكة',
                  style: GoogleFonts.poppins(),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    spreadRadius: 1,
                    blurRadius: 10,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: products.isEmpty
                    ? _buildEmptyState()
                    : ListView.separated(
                        itemCount: products.length,
                        separatorBuilder: (context, index) => const Divider(
                          height: 1,
                        ),
                        itemBuilder: (context, index) {
                          final product = products[index];
                          return _buildProductItem(product);
                        },
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProductItem(Map<String, dynamic> product) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 8,
      ),
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.network(
          product['image'] ?? 'https://picsum.photos/100',
          width: 50,
          height: 50,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) {
            return Container(
              width: 50,
              height: 50,
              color: Colors.grey.shade200,
              child: const Icon(Icons.image_not_supported),
            );
          },
        ),
      ),
      title: Text(
        product['name'] ?? '',
        style: GoogleFonts.poppins(
          fontWeight: FontWeight.w600,
        ),
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            product['category'] ?? '',
            style: GoogleFonts.poppins(
              fontSize: 12,
              color: Colors.grey,
            ),
          ),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8,
                  vertical: 2,
                ),
                decoration: BoxDecoration(
                  color: _getStatusColor(product['status'])?.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  product['status'] ?? '',
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    color: _getStatusColor(product['status']),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                '${product['quantity']} في المخزون',
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
        ],
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            '${product['price']} ر.س',
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(width: 16),
          PopupMenuButton(
            icon: const Icon(Icons.more_vert),
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'edit',
                child: Row(
                  children: [
                    Icon(Icons.edit),
                    SizedBox(width: 8),
                    Text('تعديل'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'duplicate',
                child: Row(
                  children: [
                    Icon(Icons.copy),
                    SizedBox(width: 8),
                    Text('نسخ'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'delete',
                child: Row(
                  children: [
                    Icon(Icons.delete, color: Colors.red),
                    SizedBox(width: 8),
                    Text('حذف', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
            onSelected: (value) {
              // TODO: Handle menu selection
            },
          ),
        ],
      ),
      onTap: () {
        // TODO: Navigate to product details
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.inventory_2_outlined,
            size: 64,
            color: Colors.grey.shade400,
          ),
          const SizedBox(height: 16),
          Text(
            'لا توجد منتجات',
            style: GoogleFonts.poppins(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'بدء إضافة منتجات جديدة لمتجرك',
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () {
              // TODO: Navigate to add product page
            },
            icon: const Icon(Icons.add),
            label: Text(
              'إضافة منتج جديد',
              style: GoogleFonts.poppins(),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(
                horizontal: 20,
                vertical: 12,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color? _getStatusColor(String? status) {
    switch (status) {
      case 'نشط':
        return Colors.green;
      case 'مسودة':
        return Colors.orange;
      case 'نفد من المخزون':
        return Colors.red;
      case 'أرشيف':
        return Colors.grey;
      default:
        return Colors.grey;
    }
  }

  List<Map<String, dynamic>> _getDummyProducts() {
    return [
      {
        'id': '1',
        'name': 'تيشيرت قطن بطباعة',
        'category': 'الملابس',
        'image': 'https://picsum.photos/seed/product1/100',
        'price': '٧٩.٩٩',
        'quantity': 26,
        'status': 'نشط',
      },
      {
        'id': '2',
        'name': 'بنطلون جينز كلاسيك',
        'category': 'الملابس',
        'image': 'https://picsum.photos/seed/product2/100',
        'price': '١٤٩.٩٩',
        'quantity': 18,
        'status': 'نشط',
      },
      {
        'id': '3',
        'name': 'حذاء رياضي',
        'category': 'الأحذية',
        'image': 'https://picsum.photos/seed/product3/100',
        'price': '٢٤٩.٩٩',
        'quantity': 10,
        'status': 'نشط',
      },
      {
        'id': '4',
        'name': 'ساعة يد رجالية',
        'category': 'الإكسسوارات',
        'image': 'https://picsum.photos/seed/product4/100',
        'price': '٣٩٩.٩٩',
        'quantity': 5,
        'status': 'نشط',
      },
      {
        'id': '5',
        'name': 'حقيبة جلدية',
        'category': 'الإكسسوارات',
        'image': 'https://picsum.photos/seed/product5/100',
        'price': '١٩٩.٩٩',
        'quantity': 0,
        'status': 'نفد من المخزون',
      },
      {
        'id': '6',
        'name': 'سماعات بلوتوث',
        'category': 'الإلكترونيات',
        'image': 'https://picsum.photos/seed/product6/100',
        'price': '١٢٩.٩٩',
        'quantity': 15,
        'status': 'نشط',
      },
      {
        'id': '7',
        'name': 'مصباح طاولة',
        'category': 'المنزل والحديقة',
        'image': 'https://picsum.photos/seed/product7/100',
        'price': '٨٩.٩٩',
        'quantity': 8,
        'status': 'نشط',
      },
    ];
  }
}
