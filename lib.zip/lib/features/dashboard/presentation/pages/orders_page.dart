import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../../../../core/theme/app_theme.dart';

class OrdersPage extends StatefulWidget {
  const OrdersPage({super.key});

  @override
  State<OrdersPage> createState() => _OrdersPageState();
}

class _OrdersPageState extends State<OrdersPage> {
  final TextEditingController _searchController = TextEditingController();
  String _selectedStatus = 'الكل';
  String _selectedTimeframe = 'هذا الشهر';

  final List<String> _statuses = [
    'الكل',
    'قيد الانتظار',
    'تم التأكيد',
    'قيد التجهيز',
    'جاهز',
    'في الطريق',
    'تم التسليم',
    'مكتمل',
    'ملغي',
  ];

  final List<String> _timeframes = [
    'اليوم',
    'هذا الأسبوع',
    'هذا الشهر',
    'هذا العام',
    'كل الوقت',
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(),
          _buildFilters(),
          const SizedBox(height: 16),
          _buildOrderStats(),
          Expanded(
            child: _buildOrderList(),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'البحث عن طلب...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey.shade100,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 0,
                ),
              ),
              onChanged: (value) {
                // TODO: Implement search
                setState(() {});
              },
            ),
          ),
          const SizedBox(width: 16),
          ElevatedButton.icon(
            onPressed: () {
              // TODO: Create new order
            },
            icon: const Icon(Icons.add, size: 20),
            label: Text(
              'طلب جديد',
              style: GoogleFonts.poppins(),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 12,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilters() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _buildStatusFilter(),
            const SizedBox(width: 12),
            _buildTimeframeFilter(),
            const SizedBox(width: 12),
            _buildExportButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusFilter() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _selectedStatus,
          items: _statuses.map((status) {
            return DropdownMenuItem<String>(
              value: status,
              child: Text(
                status,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                ),
              ),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedStatus = value!;
            });
          },
          icon: const Icon(Icons.keyboard_arrow_down),
          hint: Text(
            'الحالة',
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTimeframeFilter() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _selectedTimeframe,
          items: _timeframes.map((timeframe) {
            return DropdownMenuItem<String>(
              value: timeframe,
              child: Text(
                timeframe,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                ),
              ),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedTimeframe = value!;
            });
          },
          icon: const Icon(Icons.keyboard_arrow_down),
          hint: Text(
            'الفترة الزمنية',
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildExportButton() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: IconButton(
        icon: const Icon(Icons.download),
        onPressed: () {
          // TODO: Export orders
        },
        tooltip: 'تصدير الطلبات',
      ),
    );
  }

  Widget _buildOrderStats() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: _buildStatCard(
              'إجمالي الطلبات',
              '245',
              Icons.shopping_bag_outlined,
              Colors.blue,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildStatCard(
              'قيد الانتظار',
              '12',
              Icons.pending_actions,
              Colors.orange,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildStatCard(
              'تم التسليم',
              '189',
              Icons.check_circle_outline,
              Colors.green,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildStatCard(
              'ملغي',
              '8',
              Icons.cancel_outlined,
              Colors.red,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(
      String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 4,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: color,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    color: Colors.grey.shade600,
                  ),
                ),
                Text(
                  value,
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOrderList() {
    final orders = _getDummyOrders();

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'الطلبات (${orders.length})',
                style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              TextButton.icon(
                onPressed: () {
                  // TODO: Refresh orders
                },
                icon: const Icon(Icons.refresh),
                label: Text(
                  'تحديث',
                  style: GoogleFonts.poppins(),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    spreadRadius: 1,
                    blurRadius: 10,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: orders.isEmpty
                    ? _buildEmptyState()
                    : ListView.separated(
                        itemCount: orders.length,
                        separatorBuilder: (context, index) => const Divider(
                          height: 1,
                        ),
                        itemBuilder: (context, index) {
                          final order = orders[index];
                          return _buildOrderItem(order);
                        },
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOrderItem(Map<String, dynamic> order) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 8,
      ),
      leading: CircleAvatar(
        backgroundColor: _getStatusColor(order['status'])?.withOpacity(0.1),
        child: Icon(
          _getStatusIcon(order['status']),
          color: _getStatusColor(order['status']),
          size: 20,
        ),
      ),
      title: Row(
        children: [
          Text(
            '#${order['id']}',
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 8,
              vertical: 2,
            ),
            decoration: BoxDecoration(
              color: _getStatusColor(order['status'])?.withOpacity(0.1),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              order['status'] ?? '',
              style: GoogleFonts.poppins(
                fontSize: 12,
                color: _getStatusColor(order['status']),
              ),
            ),
          ),
        ],
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 4),
          Row(
            children: [
              Icon(
                Icons.person_outline,
                size: 16,
                color: Colors.grey.shade600,
              ),
              const SizedBox(width: 4),
              Text(
                order['customer_name'] ?? '',
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
              const SizedBox(width: 16),
              Icon(
                Icons.calendar_today_outlined,
                size: 16,
                color: Colors.grey.shade600,
              ),
              const SizedBox(width: 4),
              Text(
                order['date'] ?? '',
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Icon(
                Icons.shopping_bag_outlined,
                size: 16,
                color: Colors.grey.shade600,
              ),
              const SizedBox(width: 4),
              Text(
                '${order['items_count']} منتجات',
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
              const SizedBox(width: 16),
              Icon(
                Icons.payments_outlined,
                size: 16,
                color: Colors.grey.shade600,
              ),
              const SizedBox(width: 4),
              Text(
                order['payment_method'] ?? '',
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
          ),
        ],
      ),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            '${order['total']} ر.س',
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: const Icon(Icons.edit_outlined, size: 20),
                onPressed: () {
                  // TODO: Edit order
                },
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                tooltip: 'تعديل',
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: const Icon(Icons.print_outlined, size: 20),
                onPressed: () {
                  // TODO: Print order
                },
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                tooltip: 'طباعة',
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: Icon(
                  Icons.more_vert,
                  size: 20,
                  color: Colors.grey.shade600,
                ),
                onPressed: () {
                  // TODO: More options
                },
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                tooltip: 'المزيد',
              ),
            ],
          ),
        ],
      ),
      onTap: () {
        // TODO: Navigate to order details
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.shopping_bag_outlined,
            size: 64,
            color: Colors.grey.shade400,
          ),
          const SizedBox(height: 16),
          Text(
            'لا توجد طلبات',
            style: GoogleFonts.poppins(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'ستظهر الطلبات الجديدة هنا',
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () {
              // TODO: Create new order
            },
            icon: const Icon(Icons.add),
            label: Text(
              'إنشاء طلب جديد',
              style: GoogleFonts.poppins(),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(
                horizontal: 20,
                vertical: 12,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color? _getStatusColor(String? status) {
    switch (status) {
      case 'قيد الانتظار':
        return Colors.blue;
      case 'تم التأكيد':
        return Colors.indigo;
      case 'قيد التجهيز':
        return Colors.orange;
      case 'جاهز':
        return Colors.green;
      case 'في الطريق':
        return Colors.purple;
      case 'تم التسليم':
        return Colors.teal;
      case 'مكتمل':
        return Colors.green.shade800;
      case 'ملغي':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  IconData _getStatusIcon(String? status) {
    switch (status) {
      case 'قيد الانتظار':
        return Icons.hourglass_empty;
      case 'تم التأكيد':
        return Icons.thumb_up_outlined;
      case 'قيد التجهيز':
        return Icons.pending_actions;
      case 'جاهز':
        return Icons.check_circle_outline;
      case 'في الطريق':
        return Icons.local_shipping_outlined;
      case 'تم التسليم':
        return Icons.home_outlined;
      case 'مكتمل':
        return Icons.done_all;
      case 'ملغي':
        return Icons.cancel_outlined;
      default:
        return Icons.shopping_bag_outlined;
    }
  }

  List<Map<String, dynamic>> _getDummyOrders() {
    return [
      {
        'id': '1001',
        'customer_name': 'محمد أحمد',
        'date': '٢٠ مايو ٢٠٢٣',
        'status': 'مكتمل',
        'total': '٤٥٠.٠٠',
        'items_count': 3,
        'payment_method': 'بطاقة ائتمان',
      },
      {
        'id': '1002',
        'customer_name': 'خالد العتيبي',
        'date': '١٩ مايو ٢٠٢٣',
        'status': 'في الطريق',
        'total': '٣٢٠.٥٠',
        'items_count': 2,
        'payment_method': 'دفع عند الاستلام',
      },
      {
        'id': '1003',
        'customer_name': 'سارة خالد',
        'date': '١٨ مايو ٢٠٢٣',
        'status': 'جاهز',
        'total': '٦٧٥.٠٠',
        'items_count': 4,
        'payment_method': 'تحويل بنكي',
      },
      {
        'id': '1004',
        'customer_name': 'أحمد محمد',
        'date': '١٨ مايو ٢٠٢٣',
        'status': 'قيد التجهيز',
        'total': '١٨٠.٠٠',
        'items_count': 1,
        'payment_method': 'بطاقة ائتمان',
      },
      {
        'id': '1005',
        'customer_name': 'نورة سعد',
        'date': '١٧ مايو ٢٠٢٣',
        'status': 'قيد الانتظار',
        'total': '٥٤٠.٠٠',
        'items_count': 3,
        'payment_method': 'دفع عند الاستلام',
      },
      {
        'id': '1006',
        'customer_name': 'فهد العنزي',
        'date': '١٦ مايو ٢٠٢٣',
        'status': 'ملغي',
        'total': '٢٧٠.٠٠',
        'items_count': 2,
        'payment_method': 'بطاقة ائتمان',
      },
      {
        'id': '1007',
        'customer_name': 'عبدالله محمد',
        'date': '١٥ مايو ٢٠٢٣',
        'status': 'مكتمل',
        'total': '٨٩٠.٠٠',
        'items_count': 5,
        'payment_method': 'تحويل بنكي',
      },
    ];
  }
}
