import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../core/theme/app_theme.dart';

class CustomersPage extends StatefulWidget {
  const CustomersPage({super.key});

  @override
  State<CustomersPage> createState() => _CustomersPageState();
}

class _CustomersPageState extends State<CustomersPage> {
  final TextEditingController _searchController = TextEditingController();
  String _selectedFilter = 'الكل';
  String _selectedSort = 'الأحدث';

  final List<String> _filters = [
    'الكل',
    'عملاء نشطون',
    'عملاء جدد',
    'عملاء متكررون',
  ];

  final List<String> _sortOptions = [
    'الأحدث',
    'الأقدم',
    'الإنفاق (من الأعلى)',
    'الطلبات (من الأعلى)',
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(),
          _buildFilters(),
          const SizedBox(height: 16),
          _buildCustomerStats(),
          Expanded(
            child: _buildCustomerList(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // TODO: Navigate to add customer page
        },
        backgroundColor: AppTheme.primaryColor,
        child: const Icon(Icons.person_add, color: Colors.white),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'البحث عن عميل...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey.shade100,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 0,
                ),
              ),
              onChanged: (value) {
                // TODO: Implement search
                setState(() {});
              },
            ),
          ),
          const SizedBox(width: 16),
          PopupMenuButton(
            icon: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.more_vert),
            ),
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'export',
                child: Row(
                  children: [
                    Icon(Icons.download),
                    SizedBox(width: 8),
                    Text('تصدير العملاء'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'import',
                child: Row(
                  children: [
                    Icon(Icons.upload),
                    SizedBox(width: 8),
                    Text('استيراد العملاء'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'segment',
                child: Row(
                  children: [
                    Icon(Icons.group_work),
                    SizedBox(width: 8),
                    Text('إدارة الشرائح'),
                  ],
                ),
              ),
            ],
            onSelected: (value) {
              // TODO: Handle menu selection
            },
          ),
        ],
      ),
    );
  }

  Widget _buildFilters() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _buildFilterDropdown(),
            const SizedBox(width: 12),
            _buildSortDropdown(),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterDropdown() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _selectedFilter,
          items: _filters.map((filter) {
            return DropdownMenuItem<String>(
              value: filter,
              child: Text(
                filter,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                ),
              ),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedFilter = value!;
            });
          },
          icon: const Icon(Icons.keyboard_arrow_down),
          hint: Text(
            'تصفية',
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSortDropdown() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _selectedSort,
          items: _sortOptions.map((option) {
            return DropdownMenuItem<String>(
              value: option,
              child: Text(
                option,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                ),
              ),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedSort = value!;
            });
          },
          icon: const Icon(Icons.keyboard_arrow_down),
          hint: Text(
            'ترتيب',
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCustomerStats() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: _buildStatCard(
              'إجمالي العملاء',
              '523',
              Icons.people_outline,
              Colors.blue,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildStatCard(
              'عملاء جدد',
              '48',
              Icons.person_add_alt_1_outlined,
              Colors.green,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildStatCard(
              'عملاء متكررون',
              '312',
              Icons.repeat_outlined,
              Colors.purple,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildStatCard(
              'معدل الاحتفاظ',
              '76%',
              Icons.favorite_outline,
              Colors.orange,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(
      String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 4,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: color,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    color: Colors.grey.shade600,
                  ),
                ),
                Text(
                  value,
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCustomerList() {
    final customers = _getDummyCustomers();

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'العملاء (${customers.length})',
                style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              TextButton.icon(
                onPressed: () {
                  // TODO: Refresh customers
                },
                icon: const Icon(Icons.refresh),
                label: Text(
                  'تحديث',
                  style: GoogleFonts.poppins(),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    spreadRadius: 1,
                    blurRadius: 10,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: customers.isEmpty
                    ? _buildEmptyState()
                    : ListView.separated(
                        itemCount: customers.length,
                        separatorBuilder: (context, index) => const Divider(
                          height: 1,
                        ),
                        itemBuilder: (context, index) {
                          final customer = customers[index];
                          return _buildCustomerItem(customer);
                        },
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCustomerItem(Map<String, dynamic> customer) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 8,
      ),
      leading: CircleAvatar(
        backgroundImage: NetworkImage(
          customer['avatar'] ?? 'https://i.pravatar.cc/150',
        ),
        radius: 25,
      ),
      title: Row(
        children: [
          Text(
            customer['name'] ?? '',
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(width: 8),
          if (customer['is_loyal'] == true)
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 8,
                vertical: 2,
              ),
              decoration: BoxDecoration(
                color: Colors.amber.withOpacity(0.1),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.star,
                    color: Colors.amber,
                    size: 12,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'عميل مميز',
                    style: GoogleFonts.poppins(
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                      color: Colors.amber.shade800,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 4),
          Row(
            children: [
              Icon(
                Icons.email_outlined,
                size: 16,
                color: Colors.grey.shade600,
              ),
              const SizedBox(width: 4),
              Text(
                customer['email'] ?? '',
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Icon(
                Icons.phone_outlined,
                size: 16,
                color: Colors.grey.shade600,
              ),
              const SizedBox(width: 4),
              Text(
                customer['phone'] ?? '',
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
              const SizedBox(width: 16),
              Icon(
                Icons.calendar_today_outlined,
                size: 16,
                color: Colors.grey.shade600,
              ),
              const SizedBox(width: 4),
              Text(
                'انضم: ${customer['joined_date'] ?? ''}',
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
          ),
        ],
      ),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            '${customer['orders_count']} طلب',
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '${customer['total_spent']} ر.س',
            style: GoogleFonts.poppins(
              fontSize: 12,
              color: Colors.green,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
      onTap: () {
        // TODO: Navigate to customer details
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.people_outline,
            size: 64,
            color: Colors.grey.shade400,
          ),
          const SizedBox(height: 16),
          Text(
            'لا يوجد عملاء',
            style: GoogleFonts.poppins(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'أضف عملاء جدد لمتجرك',
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () {
              // TODO: Navigate to add customer page
            },
            icon: const Icon(Icons.person_add),
            label: Text(
              'إضافة عميل جديد',
              style: GoogleFonts.poppins(),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(
                horizontal: 20,
                vertical: 12,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<Map<String, dynamic>> _getDummyCustomers() {
    return [
      {
        'id': '1',
        'name': 'محمد أحمد',
        'email': 'mohamed@example.com',
        'phone': '966 50 123 4567',
        'avatar': 'https://i.pravatar.cc/150?img=1',
        'joined_date': '١٥ يناير ٢٠٢٣',
        'orders_count': 23,
        'total_spent': '٧,٦٥٠',
        'is_loyal': true,
      },
      {
        'id': '2',
        'name': 'سارة خالد',
        'email': 'sara@example.com',
        'phone': '966 55 765 4321',
        'avatar': 'https://i.pravatar.cc/150?img=5',
        'joined_date': '٣ فبراير ٢٠٢٣',
        'orders_count': 18,
        'total_spent': '٥,٨٢٠',
        'is_loyal': true,
      },
      {
        'id': '3',
        'name': 'خالد العتيبي',
        'email': 'khaled@example.com',
        'phone': '966 54 889 3322',
        'avatar': 'https://i.pravatar.cc/150?img=3',
        'joined_date': '٢٠ فبراير ٢٠٢٣',
        'orders_count': 15,
        'total_spent': '٤,٢٠٠',
        'is_loyal': false,
      },
      {
        'id': '4',
        'name': 'نورة سعد',
        'email': 'noura@example.com',
        'phone': '966 56 443 7788',
        'avatar': 'https://i.pravatar.cc/150?img=6',
        'joined_date': '٥ مارس ٢٠٢٣',
        'orders_count': 12,
        'total_spent': '٣,٧٥٠',
        'is_loyal': false,
      },
      {
        'id': '5',
        'name': 'فهد العنزي',
        'email': 'fahad@example.com',
        'phone': '966 59 112 3456',
        'avatar': 'https://i.pravatar.cc/150?img=7',
        'joined_date': '١٨ مارس ٢٠٢٣',
        'orders_count': 10,
        'total_spent': '٢,٩٠٠',
        'is_loyal': false,
      },
      {
        'id': '6',
        'name': 'منى الشمري',
        'email': 'mona@example.com',
        'phone': '966 53 667 8899',
        'avatar': 'https://i.pravatar.cc/150?img=10',
        'joined_date': '٢ أبريل ٢٠٢٣',
        'orders_count': 8,
        'total_spent': '٢,١٠٠',
        'is_loyal': false,
      },
      {
        'id': '7',
        'name': 'عبدالله محمد',
        'email': 'abdullah@example.com',
        'phone': '966 58 990 1122',
        'avatar': 'https://i.pravatar.cc/150?img=9',
        'joined_date': '١٢ أبريل ٢٠٢٣',
        'orders_count': 5,
        'total_spent': '١,٦٥٠',
        'is_loyal': false,
      },
    ];
  }
}
