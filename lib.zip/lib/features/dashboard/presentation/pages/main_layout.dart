import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dashboard_page.dart';
import 'products_page.dart';
import 'orders_page.dart';
import 'customers_page.dart';
import 'reports_page.dart';
import 'settings_page.dart';
import 'info_guide_page.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/routes/app_router.dart';

class MainLayout extends StatefulWidget {
  const MainLayout({super.key});

  @override
  State<MainLayout> createState() => _MainLayoutState();
}

class _MainLayoutState extends State<MainLayout> {
  int _selectedIndex = 0;
  late List<Widget> _pages;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _pages = [
      const DashboardPage(),
      const ProductsPage(),
      const OrdersPage(),
      const CustomersPage(),
      const InfoGuidePage(),
      const ReportsPage(),
      const SettingsPage(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text(
          _getTitle(),
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w600,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {
            _scaffoldKey.currentState?.openDrawer();
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {
              // TODO: Navigate to notifications
            },
          ),
          const SizedBox(width: 8),
          _buildProfileAvatar(),
          const SizedBox(width: 16),
        ],
      ),
      drawer: _buildDrawer(),
      body: _pages[_selectedIndex],
    );
  }

  Widget _buildProfileAvatar() {
    return GestureDetector(
      onTap: () {
        // TODO: Navigate to profile
      },
      child: const CircleAvatar(
        radius: 18,
        backgroundImage: NetworkImage(
          'https://i.pravatar.cc/100',
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: Column(
        children: [
          _buildDrawerHeader(),
          _buildDrawerItem(0, 'لوحة القيادة', Icons.dashboard_outlined),
          _buildDrawerItem(1, 'المنتجات', Icons.inventory_2_outlined),
          _buildDrawerItem(2, 'الطلبات', Icons.shopping_bag_outlined),
          _buildDrawerItem(3, 'العملاء', Icons.people_outline),
          _buildDrawerItem(4, 'دليل المعلومات', Icons.info_outline),
          _buildDrawerItem(5, 'التقارير', Icons.bar_chart_outlined),
          const Spacer(),
          _buildDrawerItem(6, 'الإعدادات', Icons.settings_outlined),
          _buildDrawerItem(7, 'اختبار الـ API', Icons.api),
          const SizedBox(height: 16),
          _buildLogoutButton(),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _buildDrawerHeader() {
    return DrawerHeader(
      decoration: const BoxDecoration(
        color: AppTheme.primaryColor,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const CircleAvatar(
                radius: 30,
                backgroundImage: NetworkImage(
                  'https://i.pravatar.cc/100',
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'متجر كرييتكس',
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      'مدير المتجر',
                      style: GoogleFonts.poppins(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              'متجر نشط',
              style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem(int index, String title, IconData icon) {
    if (index == 7) {
      return ListTile(
        leading: Icon(
          icon,
          color: AppTheme.secondaryTextColor,
        ),
        title: Text(
          title,
          style: GoogleFonts.poppins(
            color: AppTheme.textColor,
            fontWeight: FontWeight.normal,
          ),
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        onTap: () {
          Navigator.pop(context);
          Navigator.pushNamed(context, AppRouter.apiTest);
        },
      );
    }

    return ListTile(
      leading: Icon(
        icon,
        color: _selectedIndex == index
            ? AppTheme.primaryColor
            : AppTheme.secondaryTextColor,
      ),
      title: Text(
        title,
        style: GoogleFonts.poppins(
          color: _selectedIndex == index
              ? AppTheme.primaryColor
              : AppTheme.textColor,
          fontWeight:
              _selectedIndex == index ? FontWeight.w600 : FontWeight.normal,
        ),
      ),
      selected: _selectedIndex == index,
      selectedTileColor: AppTheme.primaryColor.withOpacity(0.1),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      onTap: () {
        setState(() {
          _selectedIndex = index;
        });
        Navigator.pop(context);
      },
    );
  }

  Widget _buildLogoutButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ElevatedButton.icon(
        onPressed: () {
          // TODO: Implement logout
        },
        icon: const Icon(Icons.logout, color: Colors.white),
        label: Text(
          'تسجيل الخروج',
          style: GoogleFonts.poppins(color: Colors.white),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppTheme.errorColor,
          minimumSize: const Size(double.infinity, 46),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ),
    );
  }

  String _getTitle() {
    switch (_selectedIndex) {
      case 0:
        return 'لوحة القيادة';
      case 1:
        return 'المنتجات';
      case 2:
        return 'الطلبات';
      case 3:
        return 'العملاء';
      case 4:
        return 'دليل المعلومات';
      case 5:
        return 'التقارير';
      case 6:
        return 'الإعدادات';
      default:
        return 'كرييتكس';
    }
  }
}
