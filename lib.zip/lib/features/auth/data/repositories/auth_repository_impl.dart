import 'dart:convert';
import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:creatxs/core/network/dio_client.dart';
import 'package:creatxs/features/auth/domain/models/user_model.dart';
import 'package:creatxs/features/auth/domain/repositories/auth_repository.dart';
import 'package:creatxs/features/auth/domain/models/auth_models.dart';

class AuthRepositoryImpl implements AuthRepository {
  final DioClient _dioClient;
  final SharedPreferences _prefs;
  final StreamController<UserModel?> _authStateController =
      StreamController<UserModel?>.broadcast();
  static const String _tokenKey = 'auth_token';
  static const String _baseUrl = 'https://localhost:44385/api/v1/Account';

  AuthRepositoryImpl({
    required DioClient dioClient,
    required SharedPreferences prefs,
  })  : _dioClient = dioClient,
        _prefs = prefs;

  @override
  Future<AuthResponse> registerMerchant(MerchantRegisterRequest request) async {
    try {
      final response = await _dioClient.dio.post(
        '/Account/RegisterMerchant',
        data: request.toJson(),
      );

      if (response.statusCode == 200) {
        if (request.email != null && request.password != null) {
          final loginRequest = LoginRequest(
            email: request.email,
            password: request.password,
          );
          return await loginWithRequest(loginRequest);
        } else {
          return AuthResponse(
            success: true,
            message: 'Merchant registered successfully',
          );
        }
      } else {
        return AuthResponse(success: false, message: response.statusMessage);
      }
    } on DioException catch (e) {
      return AuthResponse(success: false, message: e.message);
    }
  }

  @override
  Future<AuthResponse> registerEndUser(UserRegisterRequest request) async {
    try {
      final response = await _dioClient.post(
        '$_baseUrl/RegisterEndUser',
        data: request.toJson(),
      );
      return AuthResponse.fromJson(response.data);
    } catch (e) {
      return AuthResponse(success: false, message: e.toString());
    }
  }

  @override
  Future<AuthResponse> confirmEmail(String token) async {
    try {
      final response = await _dioClient.post(
        '$_baseUrl/ConfirmEmail',
        queryParameters: {'token': token},
      );
      return AuthResponse.fromJson(response.data);
    } catch (e) {
      return AuthResponse(success: false, message: e.toString());
    }
  }

  @override
  Future<AuthResponse> resendEmailConfirmation(EmailRequest request) async {
    try {
      final response = await _dioClient.post(
        '$_baseUrl/ResendEmailConfirmation',
        data: request.toJson(),
      );
      return AuthResponse.fromJson(response.data);
    } catch (e) {
      return AuthResponse(success: false, message: e.toString());
    }
  }

  @override
  Future<AuthResponse> forgotPassword(EmailRequest request) async {
    try {
      final response = await _dioClient.post(
        '$_baseUrl/ForgotPassword',
        data: request.toJson(),
      );
      return AuthResponse.fromJson(response.data);
    } catch (e) {
      return AuthResponse(success: false, message: e.toString());
    }
  }

  @override
  Future<void> logout() async {
    await _prefs.remove(_tokenKey);
  }

  @override
  Future<bool> isLoggedIn() async {
    final token = await getToken();
    return token != null;
  }

  @override
  Future<String?> getToken() async {
    return _prefs.getString(_tokenKey);
  }

  @override
  Future<UserModel> register({
    required String name,
    required String email,
    required String password,
    String? phone,
  }) async {
    try {
      final request = UserRegisterRequest(
        email: email,
        phoneNumber: phone ?? '',
        password: password,
      );

      final response = await _dioClient.dio.post(
        '/Account/RegisterEndUser',
        data: request.toJson(),
      );

      if (response.statusCode == 200) {
        final loginRequest = LoginRequest(
          email: email,
          password: password,
        );
        final authResponse = await loginWithRequest(loginRequest);
        if (authResponse.success && authResponse.token != null) {
          return await _getUserFromToken(authResponse.token!);
        } else {
          throw Exception(
              'فشل تسجيل الدخول بعد إنشاء الحساب: ${authResponse.message}');
        }
      } else {
        throw Exception('فشل إنشاء الحساب: ${response.statusMessage}');
      }
    } on DioException catch (e) {
      throw Exception('فشل إنشاء الحساب: ${e.message}');
    }
  }

  @override
  Future<UserModel?> getCurrentUser() async {
    final token = await getToken();
    if (token == null) return null;

    try {
      final userJson = _prefs.getString('current_user');
      if (userJson != null) {
        final user = UserModel.fromJson(jsonDecode(userJson));
        return user;
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  @override
  Future<UserModel> updateUserProfile({
    String? name,
    String? phone,
    String? avatar,
  }) async {
    try {
      // تجميع البيانات المطلوب تحديثها
      final data = <String, dynamic>{};
      if (name != null) data['name'] = name;
      if (phone != null) data['phone'] = phone;
      if (avatar != null) data['avatar'] = avatar;

      final response = await _dioClient.dio.put(
        '/Users/Profile',
        data: data,
      );

      if (response.statusCode == 200) {
        final updatedUser = UserModel.fromJson(response.data);
        await _saveUserToPrefs(updatedUser);
        _authStateController.add(updatedUser);
        return updatedUser;
      } else {
        throw Exception('فشل تحديث الملف الشخصي: ${response.statusMessage}');
      }
    } on DioException catch (e) {
      throw Exception('فشل تحديث الملف الشخصي: ${e.message}');
    }
  }

  @override
  Future<bool> isAuthenticated() async {
    final user = await getCurrentUser();
    return user != null;
  }

  @override
  String? getAuthToken() {
    return _prefs.getString(_tokenKey);
  }

  @override
  Future<UserModel> signInWithEmail(String email) async {
    // تنفيذ وهمي - يمكن تنفيذه لاحقاً عند توفر API
    final user = UserModel(
      id: 'email-user-id',
      email: email,
      name: 'مستخدم البريد',
      createdAt: DateTime.now(),
      isEmailConfirmed: false,
    );
    _authStateController.add(user);
    return user;
  }

  @override
  Future<UserModel> signInWithGoogle() async {
    // تنفيذ وهمي - يمكن تنفيذه لاحقاً عند توفر API
    final user = UserModel(
      id: 'google-user-id',
      email: 'google@example.com',
      name: 'مستخدم جوجل',
      avatar: 'https://i.pravatar.cc/150?img=3',
      createdAt: DateTime.now(),
      isEmailConfirmed: true,
    );
    _authStateController.add(user);
    return user;
  }

  @override
  Future<UserModel> signInWithFacebook() async {
    // تنفيذ وهمي - يمكن تنفيذه لاحقاً عند توفر API
    final user = UserModel(
      id: 'facebook-user-id',
      email: 'facebook@example.com',
      name: 'مستخدم فيسبوك',
      avatar: 'https://i.pravatar.cc/150?img=8',
      createdAt: DateTime.now(),
      isEmailConfirmed: true,
    );
    _authStateController.add(user);
    return user;
  }

  @override
  Future<UserModel> signInWithApple() async {
    // تنفيذ وهمي - يمكن تنفيذه لاحقاً عند توفر API
    final user = UserModel(
      id: 'apple-user-id',
      email: 'apple@example.com',
      name: 'مستخدم أبل',
      createdAt: DateTime.now(),
      isEmailConfirmed: true,
    );
    _authStateController.add(user);
    return user;
  }

  @override
  Future<void> signOut() async {
    await logout();
  }

  @override
  Stream<UserModel?> get authStateChanges => _authStateController.stream;

  @override
  Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    try {
      final response = await _dioClient.dio.post(
        '/Account/ChangePassword',
        data: {
          'currentPassword': currentPassword,
          'newPassword': newPassword,
          'confirmPassword': newPassword,
        },
      );

      if (response.statusCode != 200) {
        throw Exception('فشل تغيير كلمة المرور: ${response.statusMessage}');
      }
    } on DioException catch (e) {
      throw Exception('فشل تغيير كلمة المرور: ${e.message}');
    }
  }

  @override
  Future<void> resetPassword(String token) async {
    try {
      await _dioClient.post(
        '$_baseUrl/ResetPassword',
        queryParameters: {'token': token},
      );
    } catch (e) {
      throw Exception('Failed to reset password: ${e.toString()}');
    }
  }

  @override
  Future<AuthResponse> loginWithRequest(LoginRequest request) async {
    try {
      final response = await _dioClient.post(
        '$_baseUrl/Login',
        data: request.toJson(),
      );
      final authResponse = AuthResponse.fromJson(response.data);
      if (authResponse.success && authResponse.token != null) {
        await _prefs.setString(_tokenKey, authResponse.token!);
      }
      return authResponse;
    } catch (e) {
      return AuthResponse(success: false, message: e.toString());
    }
  }

  @override
  Future<UserModel> login({
    required String email,
    required String password,
  }) async {
    try {
      final loginRequest = LoginRequest(
        email: email,
        password: password,
      );

      final authResponse = await loginWithRequest(loginRequest);
      if (authResponse.success && authResponse.token != null) {
        return await _getUserFromToken(authResponse.token!);
      }
      throw Exception(authResponse.message ?? 'Login failed');
    } catch (e) {
      throw Exception('Login failed: $e');
    }
  }

  Future<UserModel> _getUserFromToken(String token) async {
    try {
      final response = await _dioClient.dio.get(
        '/Account/GetCurrentUser',
        options: Options(headers: {'Authorization': 'Bearer $token'}),
      );

      if (response.statusCode == 200) {
        final user = UserModel.fromJson(response.data);
        await _prefs.setString('current_user', jsonEncode(user.toJson()));
        return user;
      } else {
        throw Exception(
            'فشل الحصول على بيانات المستخدم: ${response.statusMessage}');
      }
    } on DioException catch (e) {
      throw Exception('فشل الحصول على بيانات المستخدم: ${e.message}');
    }
  }

  Future<void> _saveUserToPrefs(UserModel user) async {
    await _prefs.setString('current_user', jsonEncode(user.toJson()));
  }
}
