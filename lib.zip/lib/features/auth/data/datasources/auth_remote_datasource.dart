import 'dart:convert';
import 'package:dio/dio.dart';
import '../../domain/models/user_model.dart';
import '../../domain/models/auth_models.dart';
import '../../domain/models/merchant_register_response.dart';
import '../../domain/models/user_register_response.dart';
import '../../../../core/error/exceptions.dart';
import '../../../../core/network/api_service.dart';

abstract class AuthRemoteDataSource {
  Future<UserModel> login(String email, String password);
  Future<UserModel> registerMerchant(
      String email, String password, String storeName, String phoneNumber);
  Future<UserModel> registerEndUser(
      String email, String password, String phoneNumber);
  Future<void> confirmEmail(String token);
  Future<void> resendEmailConfirmation(String email);
  Future<void> forgotPassword(String email);
  Future<void> logout();
  Future<bool> isLoggedIn();
  Future<String?> getToken();
}

class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  final Dio dio;
  final ApiService _apiService;
  static const String baseUrl = 'https://localhost:44385/api/v1/Account';

  AuthRemoteDataSourceImpl(this.dio) : _apiService = ApiService(dio);

  @override
  Future<UserModel> login(String email, String password) async {
    try {
      if (email.isEmpty || password.isEmpty) {
        throw ServerException(message: 'Email and password are required');
      }

      final request = LoginRequest(email: email, password: password);
      final response = await _apiService.login(request);

      if (!response.success) {
        throw ServerException(message: response.message ?? 'Failed to login');
      }

      if (response.data == null) {
        throw ServerException(message: 'Invalid response data');
      }

      try {
        if (response.data is Map<String, dynamic>) {
          return UserModel.fromJson(response.data as Map<String, dynamic>);
        } else {
          throw ServerException(message: 'Invalid response data format');
        }
      } catch (e) {
        throw ServerException(message: 'Failed to parse user data');
      }
    } on DioException catch (e) {
      throw ServerException(
        message: e.response?.data['message'] ?? e.message ?? 'Failed to login',
      );
    }
  }

  @override
  Future<UserModel> registerMerchant(
    String email,
    String password,
    String storeName,
    String phoneNumber,
  ) async {
    try {
      if (email.isEmpty ||
          password.isEmpty ||
          storeName.isEmpty ||
          phoneNumber.isEmpty) {
        throw ServerException(message: 'All fields are required');
      }

      final request = MerchantRegisterRequest(
        email: email,
        password: password,
        storeName: storeName,
        phoneNumber: phoneNumber,
      );

      final response = await _apiService.registerMerchant(request);

      if (!response.success) {
        throw ServerException(
            message: response.message ?? 'Failed to register merchant');
      }

      if (response.data == null) {
        throw ServerException(message: 'Invalid response data');
      }

      final merchantData = response.data?.merchantData;
      if (merchantData == null) {
        throw ServerException(message: 'Invalid merchant data received');
      }

      try {
        return UserModel.fromJson(merchantData);
      } catch (e) {
        throw ServerException(message: 'Failed to parse merchant data');
      }
    } on DioException catch (e) {
      throw ServerException(
        message: e.response?.data['message'] ??
            e.message ??
            'Failed to register merchant',
      );
    }
  }

  @override
  Future<UserModel> registerEndUser(
    String email,
    String password,
    String phoneNumber,
  ) async {
    try {
      final request = UserRegisterRequest(
        email: email,
        password: password,
        phoneNumber: phoneNumber,
      );

      final response = await _apiService.registerEndUser(request);

      if (!response.success) {
        throw ServerException(
          message: response.message ?? 'Failed to register user',
        );
      }

      if (response.data?.userData == null) {
        throw ServerException(message: 'Invalid user data received');
      }

      try {
        return UserModel.fromJson(response.data!.userData!);
      } catch (e) {
        throw ServerException(message: 'Failed to parse user data');
      }
    } on DioException catch (e) {
      throw ServerException(
        message: e.response?.data['message'] ??
            e.message ??
            'Failed to register user',
      );
    }
  }

  @override
  Future<void> confirmEmail(String token) async {
    try {
      if (token.isEmpty) {
        throw ServerException(message: 'Token is required');
      }

      final response = await _apiService.confirmEmail(token);

      if (!response.success) {
        throw ServerException(
          message: response.message ?? 'Failed to confirm email',
        );
      }

      if (response.data == null) {
        throw ServerException(message: 'Invalid response data');
      }
    } on DioException catch (e) {
      throw ServerException(
        message: e.response?.data['message'] ??
            e.message ??
            'Failed to confirm email',
      );
    }
  }

  @override
  Future<void> resendEmailConfirmation(String email) async {
    try {
      final response =
          await _apiService.resendEmailConfirmation(EmailRequest(email: email));

      if (!response.success) {
        throw ServerException(
          message: response.message ?? 'Failed to resend email confirmation',
        );
      }
    } on DioException catch (e) {
      throw ServerException(
        message: e.response?.data['message'] ??
            e.message ??
            'Failed to resend email confirmation',
      );
    }
  }

  @override
  Future<void> forgotPassword(String email) async {
    try {
      final request = EmailRequest(email: email);
      final response = await _apiService.forgotPassword(request);

      if (!response.success) {
        throw ServerException(
          message:
              response.message ?? 'Failed to process forgot password request',
        );
      }
    } on DioException catch (e) {
      throw ServerException(
        message: e.response?.data['message'] ??
            e.message ??
            'Failed to process forgot password request',
      );
    }
  }

  @override
  Future<void> logout() async {
    try {
      final response = await _apiService.logout();
      if (!response.success) {
        throw ServerException(
          message: response.message ?? 'Failed to logout',
        );
      }
    } on DioException catch (e) {
      throw ServerException(
        message: e.response?.data['message'] ?? e.message ?? 'Failed to logout',
      );
    }
  }

  @override
  Future<bool> isLoggedIn() async {
    final token = await getToken();
    return token != null;
  }

  @override
  Future<String?> getToken() async {
    try {
      final response = await _apiService.refreshToken();
      if (response.success && response.data != null) {
        final token = response.data['token'];
        if (token != null && token.toString().isNotEmpty) {
          return token.toString();
        }
      }
      return null;
    } on DioException catch (e) {
      print('Error refreshing token: ${e.message}');
      return null;
    } catch (e) {
      print('Unexpected error while refreshing token: $e');
      return null;
    }
  }
}
