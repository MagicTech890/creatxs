import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../domain/models/auth_models.dart';
import '../../domain/repositories/auth_repository.dart';

// Events
abstract class AuthEvent extends Equatable {
  const AuthEvent();

  @override
  List<Object?> get props => [];
}

class LoginRequested extends AuthEvent {
  final LoginRequest request;

  const LoginRequested({required this.request});

  @override
  List<Object?> get props => [request];
}

class RegisterMerchantRequested extends AuthEvent {
  final MerchantRegisterRequest request;

  const RegisterMerchantRequested({required this.request});

  @override
  List<Object?> get props => [request];
}

class RegisterEndUserRequested extends AuthEvent {
  final UserRegisterRequest request;

  const RegisterEndUserRequested({required this.request});

  @override
  List<Object?> get props => [request];
}

class ForgotPasswordRequested extends AuthEvent {
  final EmailRequest request;

  const ForgotPasswordRequested({required this.request});

  @override
  List<Object?> get props => [request];
}

class LogoutRequested extends AuthEvent {}

class CheckAuthStatus extends AuthEvent {}

// States
abstract class AuthState extends Equatable {
  const AuthState();

  @override
  List<Object?> get props => [];
}

class AuthInitial extends AuthState {}

class AuthLoading extends AuthState {}

class Authenticated extends AuthState {
  final String token;

  const Authenticated({required this.token});

  @override
  List<Object?> get props => [token];
}

class Unauthenticated extends AuthState {}

class AuthError extends AuthState {
  final String message;

  const AuthError({required this.message});

  @override
  List<Object?> get props => [message];
}

// Bloc
class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthRepository _authRepository;

  AuthBloc({required AuthRepository authRepository})
      : _authRepository = authRepository,
        super(AuthInitial()) {
    on<LoginRequested>(_onLoginRequested);
    on<RegisterMerchantRequested>(_onRegisterMerchantRequested);
    on<RegisterEndUserRequested>(_onRegisterEndUserRequested);
    on<ForgotPasswordRequested>(_onForgotPasswordRequested);
    on<LogoutRequested>(_onLogoutRequested);
    on<CheckAuthStatus>(_onCheckAuthStatus);
  }

  Future<void> _onLoginRequested(
    LoginRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      final user = await _authRepository.login(
        email: event.request.email ?? '',
        password: event.request.password ?? '',
      );
      final token = await _authRepository.getToken();
      if (token != null) {
        emit(Authenticated(token: token));
      } else {
        emit(AuthError(message: 'فشل تسجيل الدخول'));
      }
    } catch (e) {
      emit(AuthError(message: e.toString()));
    }
  }

  Future<void> _onRegisterMerchantRequested(
    RegisterMerchantRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      final response = await _authRepository.registerMerchant(event.request);
      if (response.success && response.token != null) {
        emit(Authenticated(token: response.token!));
      } else {
        emit(AuthError(message: response.message ?? 'فشل تسجيل التاجر'));
      }
    } catch (e) {
      emit(AuthError(message: e.toString()));
    }
  }

  Future<void> _onRegisterEndUserRequested(
    RegisterEndUserRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      final response = await _authRepository.registerEndUser(event.request);
      if (response.success && response.token != null) {
        emit(Authenticated(token: response.token!));
      } else {
        emit(AuthError(message: response.message ?? 'فشل تسجيل المستخدم'));
      }
    } catch (e) {
      emit(AuthError(message: e.toString()));
    }
  }

  Future<void> _onForgotPasswordRequested(
    ForgotPasswordRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      final response = await _authRepository.forgotPassword(event.request);
      if (response.success) {
        emit(AuthInitial());
      } else {
        emit(AuthError(
            message:
                response.message ?? 'فشل إرسال رابط إعادة تعيين كلمة المرور'));
      }
    } catch (e) {
      emit(AuthError(message: e.toString()));
    }
  }

  Future<void> _onLogoutRequested(
    LogoutRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      await _authRepository.logout();
      emit(Unauthenticated());
    } catch (e) {
      emit(AuthError(message: e.toString()));
    }
  }

  Future<void> _onCheckAuthStatus(
    CheckAuthStatus event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      final isLoggedIn = await _authRepository.isLoggedIn();
      if (isLoggedIn) {
        final token = await _authRepository.getToken();
        if (token != null) {
          emit(Authenticated(token: token));
        } else {
          emit(Unauthenticated());
        }
      } else {
        emit(Unauthenticated());
      }
    } catch (e) {
      emit(AuthError(message: e.toString()));
    }
  }
}
