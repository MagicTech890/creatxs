class MerchantRegisterResponse {
  final bool success;
  final String? message;
  final String? token;
  final Map<String, dynamic>? merchantData;

  MerchantRegisterResponse({
    required this.success,
    this.message,
    this.token,
    this.merchantData,
  });

  factory MerchantRegisterResponse.fromJson(Map<String, dynamic> json) {
    return MerchantRegisterResponse(
      success: json['success'] as bool,
      message: json['message'] as String?,
      token: json['token'] as String?,
      merchantData: json['merchantData'] as Map<String, dynamic>?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'success': success,
      if (message != null) 'message': message,
      if (token != null) 'token': token,
      if (merchantData != null) 'merchantData': merchantData,
    };
  }
}
