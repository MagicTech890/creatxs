class UserRegisterResponse {
  final bool success;
  final String? message;
  final String? token;
  final Map<String, dynamic>? userData;

  UserRegisterResponse({
    required this.success,
    this.message,
    this.token,
    this.userData,
  });

  factory UserRegisterResponse.fromJson(Map<String, dynamic> json) {
    return UserRegisterResponse(
      success: json['success'] as bool,
      message: json['message'] as String?,
      token: json['token'] as String?,
      userData: json['userData'] as Map<String, dynamic>?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'success': success,
      if (message != null) 'message': message,
      if (token != null) 'token': token,
      if (userData != null) 'userData': userData,
    };
  }
}
