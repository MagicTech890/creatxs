import 'package:json_annotation/json_annotation.dart';

part 'auth_models.g.dart';

@JsonSerializable()
class MerchantRegisterRequest {
  final String? storeName;
  final String? email;
  final String? phoneNumber;
  final String? password;

  MerchantRegisterRequest({
    this.storeName,
    this.email,
    this.phoneNumber,
    this.password,
  });

  factory MerchantRegisterRequest.fromJson(Map<String, dynamic> json) =>
      _$MerchantRegisterRequestFromJson(json);

  Map<String, dynamic> toJson() => _$MerchantRegisterRequestToJson(this);
}

@JsonSerializable()
class UserRegisterRequest {
  final String? email;
  final String? phoneNumber;
  final String? password;

  UserRegisterRequest({
    this.email,
    this.phoneNumber,
    this.password,
  });

  factory UserRegisterRequest.fromJson(Map<String, dynamic> json) =>
      _$UserRegisterRequestFromJson(json);

  Map<String, dynamic> toJson() => _$UserRegisterRequestToJson(this);
}

class LoginRequest {
  final String? email;
  final String? password;

  LoginRequest({this.email, this.password});

  Map<String, dynamic> toJson() => {
        'email': email,
        'password': password,
      };

  factory LoginRequest.fromJson(Map<String, dynamic> json) {
    return LoginRequest(
      email: json['email'] as String?,
      password: json['password'] as String?,
    );
  }
}

@JsonSerializable()
class EmailRequest {
  final String? email;

  EmailRequest({
    this.email,
  });

  factory EmailRequest.fromJson(Map<String, dynamic> json) =>
      _$EmailRequestFromJson(json);

  Map<String, dynamic> toJson() => _$EmailRequestToJson(this);
}

@JsonSerializable()
class AuthResponse {
  final bool success;
  final String? message;
  final String? token;
  final Map<String, dynamic>? userData;

  AuthResponse({
    required this.success,
    this.message,
    this.token,
    this.userData,
  });

  factory AuthResponse.fromJson(Map<String, dynamic> json) {
    return AuthResponse(
      success: json['success'] as bool,
      message: json['message'] as String?,
      token: json['token'] as String?,
      userData: json['userData'] as Map<String, dynamic>?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'success': success,
      if (message != null) 'message': message,
      if (token != null) 'token': token,
      if (userData != null) 'userData': userData,
    };
  }
}
