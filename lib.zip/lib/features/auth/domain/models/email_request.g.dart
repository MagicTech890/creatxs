// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'email_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EmailRequest _$EmailRequestFromJson(Map<String, dynamic> json) => EmailRequest(
      email: json['email'] as String?,
    );

Map<String, dynamic> _$EmailRequestToJson(EmailRequest instance) =>
    <String, dynamic>{
      'email': instance.email,
    };
