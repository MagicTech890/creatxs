// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'notification_ids_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

NotificationIdsRequest _$NotificationIdsRequestFromJson(
        Map<String, dynamic> json) =>
    NotificationIdsRequest(
      ids: (json['ids'] as List<dynamic>).map((e) => e as String).toList(),
    );

Map<String, dynamic> _$NotificationIdsRequestToJson(
        NotificationIdsRequest instance) =>
    <String, dynamic>{
      'ids': instance.ids,
    };
