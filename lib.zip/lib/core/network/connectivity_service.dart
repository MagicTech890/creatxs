import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';

class ConnectivityService extends ChangeNotifier {
  final _connectivity = Connectivity();
  final _controller = StreamController<bool>.broadcast();
  StreamSubscription? _subscription;
  bool _hasConnection = true;
  bool _isCheckingConnection = false;

  Stream<bool> get onConnectivityChanged => _controller.stream;
  bool get hasConnection => _hasConnection;
  bool get isCheckingConnection => _isCheckingConnection;

  ConnectivityService() {
    _subscription = _connectivity.onConnectivityChanged.listen(_checkStatus);
    _checkStatus();
  }

  Future<void> _checkStatus([ConnectivityResult? result]) async {
    if (_isCheckingConnection) return;

    _isCheckingConnection = true;
    notifyListeners();

    try {
      result ??= await _connectivity.checkConnectivity();
      final isConnected = result != ConnectivityResult.none;

      if (_hasConnection != isConnected) {
        _hasConnection = isConnected;
        _controller.add(_hasConnection);
        notifyListeners();
      }
    } finally {
      _isCheckingConnection = false;
      notifyListeners();
    }
  }

  Future<bool> isConnected() async {
    if (!_isCheckingConnection) {
      await _checkStatus();
    }
    return _hasConnection;
  }

  @override
  void dispose() {
    _subscription?.cancel();
    _controller.close();
    super.dispose();
  }
}
