import 'dart:convert';
import 'package:dio/dio.dart';
import 'api_service.dart';
import '../../features/notifications/domain/models/notification_ids_request.dart';
import '../../features/auth/domain/models/auth_models.dart';

class ApiClient {
  final ApiService _apiService;

  ApiClient(Dio dio) : _apiService = ApiService(dio);

  // Authentication methods
  Future<dynamic> login(String email, String password) async {
    final request = LoginRequest(email: email, password: password);
    final response = await _apiService.login(request);
    return response.data;
  }

  Future<dynamic> registerEndUser(
      String email, String phoneNumber, String password) async {
    final request = UserRegisterRequest(
      email: email,
      phoneNumber: phoneNumber,
      password: password,
    );
    final response = await _apiService.registerEndUser(request);
    return response.data;
  }

  Future<dynamic> registerMerchant(String storeName, String email,
      String phoneNumber, String password) async {
    final request = MerchantRegisterRequest(
      storeName: storeName,
      email: email,
      phoneNumber: phoneNumber,
      password: password,
    );
    final response = await _apiService.registerMerchant(request);
    return response.data;
  }

  Future<dynamic> confirmEmail(String token) async {
    final response = await _apiService.confirmEmail(token);
    return response.data;
  }

  Future<dynamic> resendEmailConfirmation(String email) async {
    final request = EmailRequest(email: email);
    final response = await _apiService.resendEmailConfirmation(request);
    return response.data;
  }

  Future<dynamic> forgotPassword(String email) async {
    final request = EmailRequest(email: email);
    final response = await _apiService.forgotPassword(request);
    return response.data;
  }

  Future<Map<String, dynamic>> getRevenueAnalytics(
      {String? startDate, String? endDate}) async {
    final response = await _apiService.getRevenueAnalytics(
        startDate: startDate, endDate: endDate);
    return response.data ?? {};
  }

  Future<List<Map<String, dynamic>>> getTopCustomers(
      {int limit = 10, String period = "week"}) async {
    final response =
        await _apiService.getTopCustomers(limit: limit, period: period);
    return response.data ?? [];
  }

  Future<Map<String, dynamic>> getSettings() async {
    final response = await _apiService.getSettings();
    return response.data ?? {};
  }

  Future<Map<String, dynamic>> getProfile() async {
    final response = await _apiService.getProfile();
    return response.data ?? {};
  }

  Future<List<Map<String, dynamic>>> getNotifications(
      {int page = 1, int limit = 20}) async {
    final response =
        await _apiService.getNotifications(page: page, limit: limit);
    return response.data ?? [];
  }

  // Delegate other methods directly to the API service
  Future<void> updateSettings(Map<String, dynamic> settings) =>
      _apiService.updateSettings(settings);

  Future<void> updateProfile(Map<String, dynamic> profile) =>
      _apiService.updateProfile(profile);

  Future<void> markNotificationsAsRead(List<String> notificationIds) =>
      _apiService.markNotificationsAsRead(
          NotificationIdsRequest(ids: notificationIds));

  // اختبار توصيل الـ API
  Future<dynamic> getWeatherForecast() async {
    final response = await _apiService.getWeatherForecast();
    return response.data ?? [];
  }
}
