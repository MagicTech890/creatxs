import 'package:flutter/material.dart';
import '../services/storage_service.dart';

class SettingsService {
  final StorageService _storageService;

  SettingsService(this._storageService);

  // Theme
  ThemeMode getThemeMode() {
    final isDark = _storageService.getDarkMode();
    return isDark ? ThemeMode.dark : ThemeMode.light;
  }

  Future<void> updateThemeMode(ThemeMode theme) async {
    await _storageService.setDarkMode(theme == ThemeMode.dark);
  }

  // Language
  Locale getLocale() {
    final locale = _storageService.getLocale();
    return Locale(locale);
  }

  Future<void> updateLocale(Locale locale) async {
    await _storageService.setLocale(locale.languageCode);
  }

  // Notifications
  bool getNotificationsEnabled() {
    return _storageService.getBool('notifications_enabled') ?? true;
  }

  Future<void> setNotificationsEnabled(bool enabled) async {
    await _storageService.setBool('notifications_enabled', enabled);
  }

  // Font Size
  double getFontScale() {
    return _storageService.getDouble('font_scale') ?? 1.0;
  }

  Future<void> setFontScale(double scale) async {
    await _storageService.setDouble('font_scale', scale);
  }
}
