import 'dart:convert';
import 'package:dio/dio.dart';
import '../network/api_service.dart';
import '../services/storage_service.dart';
import '../../features/auth/domain/models/auth_models.dart';
import '../../features/auth/domain/models/merchant_register_response.dart';
import '../../features/auth/domain/models/user_register_response.dart';
import '../../features/auth/domain/models/auth_response.dart' as auth_response;
import '../network/api_response.dart';
import 'package:flutter/foundation.dart';
import '../../features/auth/domain/models/user_model.dart';

class AuthService {
  final ApiService _apiService;
  final StorageService _storageService;

  AuthService(this._apiService, this._storageService);

  Future<auth_response.AuthResponse> login(
      {required String email, required String password}) async {
    try {
      if (email.isEmpty || !email.contains('@')) {
        return auth_response.AuthResponse(
          success: false,
          message: 'يرجى إدخال بريد إلكتروني صحيح',
        );
      }
      if (password.isEmpty || password.length < 6) {
        return auth_response.AuthResponse(
          success: false,
          message: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل',
        );
      }

      final request = LoginRequest(email: email, password: password);
      final response = await _apiService.login(request);

      if (response.success && response.data != null) {
        final data = response.data as Map<String, dynamic>;
        await _storageService.setToken(data['token']);
        return auth_response.AuthResponse(
          success: true,
          token: data['token'],
          message: 'تم تسجيل الدخول بنجاح',
        );
      }
      return auth_response.AuthResponse(
        success: false,
        message: response.message ?? 'فشل تسجيل الدخول',
      );
    } catch (e) {
      debugPrint('خطأ في تسجيل الدخول: $e');
      return auth_response.AuthResponse(
        success: false,
        message: 'حدث خطأ غير متوقع، يرجى المحاولة مرة أخرى',
      );
    }
  }

  Future<auth_response.AuthResponse> registerMerchant({
    required String storeName,
    required String email,
    required String phoneNumber,
    required String password,
  }) async {
    try {
      // التحقق من صحة المدخلات
      if (storeName.isEmpty) {
        return auth_response.AuthResponse(
          success: false,
          message: 'يرجى إدخال اسم المتجر',
        );
      }
      if (email.isEmpty || !email.contains('@')) {
        return auth_response.AuthResponse(
          success: false,
          message: 'يرجى إدخال بريد إلكتروني صحيح',
        );
      }
      if (phoneNumber.isEmpty || phoneNumber.length < 8) {
        return auth_response.AuthResponse(
          success: false,
          message: 'يرجى إدخال رقم هاتف صحيح',
        );
      }
      if (password.isEmpty || password.length < 6) {
        return auth_response.AuthResponse(
          success: false,
          message: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل',
        );
      }

      final request = MerchantRegisterRequest(
        storeName: storeName,
        email: email,
        phoneNumber: phoneNumber,
        password: password,
      );

      final response = await _apiService.registerMerchant(request);

      if (!response.success) {
        return auth_response.AuthResponse(
          success: false,
          message: response.message ?? 'حدث خطأ أثناء التسجيل',
        );
      }

      if (response.data?.token != null) {
        await _storageService.setToken(response.data!.token!);
        return auth_response.AuthResponse(
          success: true,
          token: response.data?.token,
          message: 'تم تسجيل المتجر بنجاح',
        );
      }

      return auth_response.AuthResponse(
        success: false,
        message: 'حدث خطأ أثناء إنشاء جلسة المستخدم',
      );
    } catch (e) {
      debugPrint('خطأ في تسجيل المتجر: $e');
      return auth_response.AuthResponse(
        success: false,
        message: 'حدث خطأ غير متوقع، يرجى المحاولة مرة أخرى',
      );
    }
  }

  Future<auth_response.AuthResponse> registerMerchantWithRequest(
      MerchantRegisterRequest request) async {
    try {
      final response = await _apiService.registerMerchant(request);
      if (response.data?.token != null) {
        await _storageService.setToken(response.data!.token!);
      }
      return auth_response.AuthResponse(
        success: true,
        token: response.data?.token,
      );
    } catch (e) {
      return auth_response.AuthResponse(success: false, message: e.toString());
    }
  }

  Future<void> logout() async {
    try {
      await _apiService.logout();
    } finally {
      await _storageService.remove('token');
    }
  }

  Future<bool> isLoggedIn() async {
    final token = _storageService.getToken();
    return token != null && token.isNotEmpty;
  }

  Future<String?> getToken() async {
    return _storageService.getToken();
  }

  Future<UserModel?> getCurrentUser() async {
    try {
      final response = await _apiService.getCurrentUser();
      if (response.success && response.data != null) {
        return UserModel.fromJson(response.data as Map<String, dynamic>);
      }
      return null;
    } catch (e) {
      print('Get current user error: $e');
      return null;
    }
  }

  Future<auth_response.AuthResponse> registerEndUser(
      String email, String password, String? phoneNumber) async {
    try {
      if (email.isEmpty || !email.contains('@')) {
        return auth_response.AuthResponse(
          success: false,
          message: 'يرجى إدخال بريد إلكتروني صحيح',
        );
      }
      if (password.isEmpty || password.length < 6) {
        return auth_response.AuthResponse(
          success: false,
          message: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل',
        );
      }

      final request = UserRegisterRequest(
        email: email,
        password: password,
        phoneNumber: phoneNumber,
      );

      final response = await _apiService.registerEndUser(request);

      if (response.success && response.data?.token != null) {
        await _storageService.setToken(response.data!.token!);
        return auth_response.AuthResponse(
          success: true,
          token: response.data?.token,
          message: 'تم تسجيل الحساب بنجاح',
        );
      }
      return auth_response.AuthResponse(
        success: false,
        message: response.message ?? 'فشل تسجيل الحساب',
      );
    } catch (e) {
      debugPrint('خطأ في تسجيل المستخدم: $e');
      return auth_response.AuthResponse(
        success: false,
        message: 'حدث خطأ غير متوقع، يرجى المحاولة مرة أخرى',
      );
    }
  }

  Future<auth_response.AuthResponse> registerEndUserWithRequest(
      UserRegisterRequest request) async {
    try {
      if (request.email.isEmpty || !request.email.contains('@')) {
        return auth_response.AuthResponse(
          success: false,
          message: 'يرجى إدخال بريد إلكتروني صحيح',
        );
      }
      if (request.password.isEmpty || request.password.length < 6) {
        return auth_response.AuthResponse(
          success: false,
          message: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل',
        );
      }

      final response = await _apiService.registerEndUser(request);

      if (response.success && response.data?.token != null) {
        await _storageService.setToken(response.data!.token!);
        return auth_response.AuthResponse(
          success: true,
          token: response.data?.token,
          message: 'تم تسجيل الحساب بنجاح',
        );
      }
      return auth_response.AuthResponse(
        success: false,
        message: response.message ?? 'فشل تسجيل الحساب',
      );
    } catch (e) {
      debugPrint('خطأ في تسجيل المستخدم: $e');
      return auth_response.AuthResponse(
        success: false,
        message: 'حدث خطأ غير متوقع، يرجى المحاولة مرة أخرى',
      );
    }
  }

  Future<String?> refreshToken() async {
    try {
      final response = await _apiService.refreshToken();
      final authResponse = auth_response.AuthResponse.fromJson(response.data);
      if (authResponse.success && authResponse.token != null) {
        await _storageService.setToken(authResponse.token!);
        return authResponse.token;
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  Future<auth_response.AuthResponse> confirmEmail(String token) async {
    try {
      final response = await _apiService.confirmEmail(token);
      return auth_response.AuthResponse(
        success: response.success,
        message: response.message,
      );
    } catch (e) {
      return auth_response.AuthResponse(success: false, message: e.toString());
    }
  }

  Future<auth_response.AuthResponse> resendEmailConfirmation(
      String email) async {
    try {
      final request = EmailRequest(email: email);
      final response = await _apiService.resendEmailConfirmation(request);
      return auth_response.AuthResponse(
        success: response.success,
        message: response.message,
      );
    } catch (e) {
      return auth_response.AuthResponse(success: false, message: e.toString());
    }
  }

  Future<auth_response.AuthResponse> forgotPassword(String email) async {
    try {
      final request = EmailRequest(email: email);
      final response = await _apiService.forgotPassword(request);
      return auth_response.AuthResponse(
        success: response.success,
        message: response.message,
      );
    } catch (e) {
      return auth_response.AuthResponse(success: false, message: e.toString());
    }
  }
}
