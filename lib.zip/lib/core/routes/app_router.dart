import 'package:flutter/material.dart';
import '../../features/auth/presentation/pages/login_page.dart';
import '../../features/auth/presentation/pages/register_page.dart';
import '../../features/auth/presentation/pages/forgot_password_page.dart';
import '../../features/dashboard/presentation/pages/dashboard_page.dart';
import '../../features/orders/presentation/pages/orders_page.dart';
import '../../features/products/presentation/pages/products_page.dart';
import '../../features/stores/presentation/pages/stores_page.dart';
import '../../features/profile/presentation/pages/profile_page.dart';
import '../../features/settings/presentation/pages/settings_page.dart';
import '../../features/api_test/presentation/pages/api_test_page.dart';
import '../providers/auth_provider.dart';

class AppRouter {
  static const String login = '/';
  static const String register = '/register';
  static const String forgotPassword = '/forgot-password';
  static const String dashboard = '/dashboard';
  static const String orders = '/orders';
  static const String products = '/products';
  static const String stores = '/stores';
  static const String profile = '/profile';
  static const String settings = '/settings';
  static const String apiTest = '/api-test';

  static Route<dynamic> generateRoute(RouteSettings routeSettings) {
    switch (routeSettings.name) {
      case login:
        return MaterialPageRoute(builder: (_) => const LoginPage());
      case register:
        return MaterialPageRoute(builder: (_) => const RegisterPage());
      case forgotPassword:
        return MaterialPageRoute(builder: (_) => const ForgotPasswordPage());
      case dashboard:
        return MaterialPageRoute(builder: (_) => const DashboardPage());
      case orders:
        return MaterialPageRoute(builder: (_) => const OrdersPage());
      case products:
        return MaterialPageRoute(builder: (_) => const ProductsPage());
      case stores:
        return MaterialPageRoute(builder: (_) => const StoresPage());
      case profile:
        return MaterialPageRoute(builder: (_) => const ProfilePage());
      case settings:
        return MaterialPageRoute(builder: (_) => const SettingsPage());
      case apiTest:
        return MaterialPageRoute(builder: (_) => const ApiTestPage());
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(
              child: Text('No route defined for ${routeSettings.name}'),
            ),
          ),
        );
    }
  }

  static void handleAuthState(BuildContext context, AuthState state) {
    if (state.isAuthenticated) {
      Navigator.pushReplacementNamed(context, dashboard);
    } else if (!state.isAuthenticated && !state.isLoading) {
      Navigator.pushReplacementNamed(context, login);
    }
  }
}
