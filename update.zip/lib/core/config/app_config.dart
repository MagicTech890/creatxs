import 'package:flutter/material.dart';

enum Environment { development, production }

class AppConfig {
  static final AppConfig _instance = AppConfig._internal();
  factory AppConfig() => _instance;
  AppConfig._internal();

  Environment environment = Environment.development;

  // ضبط البيئة
  void setEnvironment(Environment env) {
    environment = env;
  }

  // الحصول على عنوان API المناسب
  String get apiBaseUrl {
    switch (environment) {
      case Environment.development:
        // عنوان API المحلي للتطوير
        return 'http://localhost:5275/api';
      case Environment.production:
        // عنوان API للإنتاج (قم بتغييره إلى عنوان API الجاهز الخاص بك)
        return 'https://api.creatxs.com/api';
    }
  }

  // عنوان IIS Express
  String get iisExpressUrl {
    return 'http://localhost:51679/api';
  }

  // إعدادات قاعدة البيانات
  String get connectionString {
    return 'Data Source=.;Initial Catalog=Creatxs;Integrated Security=True;TrustServerCertificate=true';
  }

  // إعدادات JWT
  Map<String, String> get jwtSettings {
    return {
      'key': 'YourSecretKeyHere',
      'issuer': 'YourIssuer',
      'audience': 'YourAudience',
    };
  }

  // إعدادات Serilog
  Map<String, dynamic> get loggingSettings {
    return {
      'minimumLevel': 'Information',
      'logFilePath': 'Logs/applog-.txt',
      'retainedFileCountLimit': 30,
    };
  }

  // إعدادات البريد الإلكتروني
  Map<String, dynamic> get emailSettings {
    return {
      'to': 'moh_samir_86@hotmail.com',
      'from': 'cc@outlook.com',
      'smtpHost': 'smtp.office365.com',
      'smtpPort': 587,
      'password': '***********', // لا تخزن كلمات المرور في الكود الفعلي
      'sslEnabled': true,
    };
  }

  // عنوان التطبيق
  String get appUrl {
    return 'https://yourapp.com/';
  }

  static const String appName = 'Creatxs';

  // App Theme Colors
  static const Color primaryColor = Color(0xFF2196F3);
  static const Color secondaryColor = Color(0xFF1976D2);
  static const Color accentColor = Color(0xFF64B5F6);
  static const Color backgroundColor = Color(0xFFF5F5F5);
  static const Color textColor = Color(0xFF333333);

  // API Endpoints
  static const String loginEndpoint = '/auth/login';
  static const String registerEndpoint = '/auth/register';
  static const String storesEndpoint = '/stores';
  static const String ordersEndpoint = '/orders';

  // Shared Preferences Keys
  static const String tokenKey = 'auth_token';
  static const String userKey = 'user_data';
  static const String themeKey = 'app_theme';
  static const String languageKey = 'app_language';

  // Default Settings
  static const Locale defaultLocale = Locale('ar');
  static const bool isDarkModeDefault = false;

  // Timeouts
  static const int connectionTimeout = 30000; // 30 seconds
  static const int receiveTimeout = 30000; // 30 seconds

  // Cache Configuration
  static const int maxCacheAge = 7; // days
  static const int maxCacheSize = 50; // MB

  // Pagination
  static const int defaultPageSize = 20;

  // Validation Rules
  static const int minPasswordLength = 8;
  static const int maxPasswordLength = 32;
  static const int maxUsernameLength = 50;
  static const int maxStoreNameLength = 100;

  // Feature Flags
  static const bool enablePushNotifications = true;
  static const bool enableAnalytics = true;
  static const bool enableCrashReporting = true;

  // Social Auth Client IDs
  static const String googleClientId = 'your-google-client-id';
  static const String facebookAppId = 'your-facebook-app-id';

  // App Store IDs
  static const String iOSAppId = 'your-ios-app-id';
  static const String androidPackageName = 'com.creatxs.app';
}
