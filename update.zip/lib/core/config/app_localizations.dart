import 'package:flutter/material.dart';

class AppLocalizations {
  final Locale locale;

  AppLocalizations(this.locale);

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const Map<String, Map<String, String>> _localizedValues = {
    'ar': {
      // Auth
      'login': 'تسجيل الدخول',
      'register': 'تسجيل جديد',
      'email': 'البريد الإلكتروني',
      'password': 'كلمة المرور',
      'continue': 'متابعة',
      'or_continue_with': 'أو المتابعة باستخدام',
      'your_data_is_protected': 'بياناتك محمية',

      // Dashboard
      'dashboard': 'لوحة القيادة',
      'orders': 'الطلبات',
      'stores': 'المتاجر',
      'analytics': 'التحليلات',
      'settings': 'الإعدادات',
      'notifications': 'الإشعارات',

      // Orders Status
      'all': 'الكل',
      'pending': 'معلق',
      'confirmed': 'مؤكد',
      'shipped': 'تم الشحن',
      'delivered': 'تم التسليم',
      'cancelled': 'ملغي',

      // Store Management
      'create_store': 'إنشاء متجر',
      'store_name': 'اسم المتجر',
      'store_description': 'وصف المتجر',
      'store_category': 'تصنيف المتجر',
      'store_logo': 'شعار المتجر',

      // Analytics
      'sales': 'المبيعات',
      'revenue': 'الإيرادات',
      'customers': 'العملاء',
      'products': 'المنتجات',
      'top_selling': 'الأكثر مبيعاً',

      // Settings
      'account_settings': 'إعدادات الحساب',
      'notification_settings': 'إعدادات الإشعارات',
      'language': 'اللغة',
      'theme': 'المظهر',
      'privacy_policy': 'سياسة الخصوصية',
      'terms_conditions': 'الشروط والأحكام',
      'logout': 'تسجيل الخروج',

      // General
      'search': 'بحث',
      'filter': 'تصفية',
      'sort': 'ترتيب',
      'save': 'حفظ',
      'cancel': 'إلغاء',
      'delete': 'حذف',
      'edit': 'تعديل',
      'add': 'إضافة',
      'remove': 'إزالة',
      'confirm': 'تأكيد',

      // Messages
      'success': 'تم بنجاح',
      'error': 'حدث خطأ',
      'loading': 'جاري التحميل',
      'no_data': 'لا توجد بيانات',
      'no_internet': 'لا يوجد اتصال بالإنترنت',
    },
  };

  String get(String key) {
    return _localizedValues[locale.languageCode]?[key] ?? key;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    return ['ar'].contains(locale.languageCode);
  }

  @override
  Future<AppLocalizations> load(Locale locale) async {
    return AppLocalizations(locale);
  }

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}
