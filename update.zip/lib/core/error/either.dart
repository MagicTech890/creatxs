class Either<L, R> {
  final L? _left;
  final R? _right;
  final bool isLeft;

  Either._internal(this._left, this._right, this.isLeft);

  factory Either.left(L value) {
    return Either._internal(value, null, true);
  }

  factory Either.right(R value) {
    return Either._internal(null, value, false);
  }

  T fold<T>(T Function(L) onLeft, T Function(R) onRight) {
    if (isLeft) {
      return onLeft(_left!);
    } else {
      return onRight(_right!);
    }
  }

  bool get isRight => !isLeft;

  L get left => _left!;
  R get right => _right!;
}
