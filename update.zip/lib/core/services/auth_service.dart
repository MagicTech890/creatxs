import '../network/api_service.dart';
import '../services/storage_service.dart';
import '../../features/auth/domain/models/auth_models.dart';
import '../../features/auth/domain/models/auth_response.dart' as auth_response;
import '../../features/auth/domain/models/user_model.dart';
import 'package:flutter/foundation.dart';

class AuthService {
  final ApiService _apiService;
  final StorageService _storageService;

  AuthService(this._apiService, this._storageService);

  Future<bool> login({required String email, required String password}) async {
    try {
      final request = LoginRequest(email: email, password: password);
      final response = await _apiService.login(request);

      if (response.success && response.data != null) {
        final data = response.data as Map<String, dynamic>;
        await _storageService.setToken(data['token']);
        return true;
      }
      return false;
    } catch (e) {
      print('Login error: $e');
      return false;
    }
  }

  Future<auth_response.AuthResponse> registerMerchant({
    required String storeName,
    required String email,
    required String phoneNumber,
    required String password,
  }) async {
    try {
      final request = MerchantRegisterRequest(
        storeName: storeName,
        email: email,
        phoneNumber: phoneNumber,
        password: password,
      );
      final response = await _apiService.registerMerchant(request);
      if (response.data?.token != null) {
        await _storageService.setToken(response.data!.token!);
      }
      return auth_response.AuthResponse(
        success: true,
        token: response.data?.token,
      );
    } catch (e) {
      return auth_response.AuthResponse(success: false, message: e.toString());
    }
  }

  Future<auth_response.AuthResponse> registerMerchantWithRequest(
      MerchantRegisterRequest request) async {
    try {
      final response = await _apiService.registerMerchant(request);
      if (response.data?.token != null) {
        await _storageService.setToken(response.data!.token!);
      }
      return auth_response.AuthResponse(
        success: true,
        token: response.data?.token,
      );
    } catch (e) {
      return auth_response.AuthResponse(success: false, message: e.toString());
    }
  }

  Future<void> logout() async {
    try {
      await _apiService.logout();
    } finally {
      await _storageService.remove('token');
    }
  }

  Future<bool> isLoggedIn() async {
    final token = _storageService.getToken();
    return token != null && token.isNotEmpty;
  }

  Future<String?> getToken() async {
    return _storageService.getToken();
  }

  Future<bool> registerEndUser(
      String email, String password, String? phoneNumber) async {
    try {
      final request = UserRegisterRequest(
        email: email,
        password: password,
        phoneNumber: phoneNumber,
      );

      final response = await _apiService.registerEndUser(request);

      if (response.success && response.data?.token != null) {
        await _storageService.setToken(response.data!.token!);
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('Error in registerEndUser: $e');
      return false;
    }
  }

  Future<bool> registerEndUserWithRequest(UserRegisterRequest request) async {
    try {
      final response = await _apiService.registerEndUser(request);

      if (response.success && response.data?.token != null) {
        await _storageService.setToken(response.data!.token!);
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('Error in registerEndUserWithRequest: $e');
      return false;
    }
  }

  Future<String?> refreshToken() async {
    try {
      final response = await _apiService.refreshToken();
      final authResponse = auth_response.AuthResponse.fromJson(response.data);
      if (authResponse.success && authResponse.token != null) {
        await _storageService.setToken(authResponse.token!);
        return authResponse.token;
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  Future<auth_response.AuthResponse> confirmEmail(String token) async {
    try {
      final response = await _apiService.confirmEmail(token);
      return auth_response.AuthResponse(
        success: response.success,
        message: response.message,
      );
    } catch (e) {
      return auth_response.AuthResponse(success: false, message: e.toString());
    }
  }

  Future<auth_response.AuthResponse> resendEmailConfirmation(
      String email) async {
    try {
      final request = EmailRequest(email: email);
      final response = await _apiService.resendEmailConfirmation(request);
      return auth_response.AuthResponse(
        success: response.success,
        message: response.message,
      );
    } catch (e) {
      return auth_response.AuthResponse(success: false, message: e.toString());
    }
  }

  Future<auth_response.AuthResponse> forgotPassword(String email) async {
    try {
      final request = EmailRequest(email: email);
      final response = await _apiService.forgotPassword(request);
      return auth_response.AuthResponse(
        success: response.success,
        message: response.message,
      );
    } catch (e) {
      return auth_response.AuthResponse(success: false, message: e.toString());
    }
  }

  Future<UserModel?> getCurrentUser() async {
    try {
      final token = await _storageService.getToken();
      if (token == null) return null;

      final response = await _apiService.getProfile();
      if (response.success && response.data != null) {
        final data = response.data as Map<String, dynamic>;
        return UserModel.fromJson(data);
      }
      return null;
    } catch (e) {
      debugPrint('Error getting current user: $e');
      return null;
    }
  }
}
