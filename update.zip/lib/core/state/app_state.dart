import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../network/connectivity_service.dart';
import '../services/auth_service.dart';
import '../../features/auth/domain/models/user_model.dart';
import '../providers/auth_provider.dart';

enum AppStatus {
  initial,
  authenticated,
  unauthenticated,
  error,
}

class AppState {
  final AppStatus status;
  final UserModel? user;
  final bool isLoading;
  final String? error;
  final bool isConnected;

  AppState({
    this.status = AppStatus.initial,
    this.user,
    this.isLoading = false,
    this.error,
    this.isConnected = true,
  });

  AppState copyWith({
    AppStatus? status,
    UserModel? user,
    bool? isLoading,
    String? error,
    bool? isConnected,
  }) {
    return AppState(
      status: status ?? this.status,
      user: user ?? this.user,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
      isConnected: isConnected ?? this.isConnected,
    );
  }
}

class AppStateNotifier extends StateNotifier<AppState> {
  final AuthService _authService;
  final ConnectivityService _connectivityService;

  AppStateNotifier(
    this._authService,
    this._connectivityService,
  ) : super(AppState()) {
    _init();
    _listenToConnectivity();
  }

  Future<void> _init() async {
    state = state.copyWith(isLoading: true);

    try {
      final isLoggedIn = await _authService.isLoggedIn();
      if (isLoggedIn) {
        state = state.copyWith(
          status: AppStatus.authenticated,
          isLoading: false,
        );
      } else {
        state = state.copyWith(
          status: AppStatus.unauthenticated,
          isLoading: false,
        );
      }
    } catch (e) {
      state = state.copyWith(
        status: AppStatus.error,
        error: e.toString(),
        isLoading: false,
      );
    }
  }

  void _listenToConnectivity() {
    _connectivityService.onConnectivityChanged.listen((isConnected) {
      state = state.copyWith(isConnected: isConnected);
    });
  }

  Future<void> login(String email, String password) async {
    if (email.isEmpty || password.isEmpty) {
      state = state.copyWith(
        error: 'يرجى إدخال البريد الإلكتروني وكلمة المرور',
        status: AppStatus.error,
      );
      return;
    }

    if (!state.isConnected) {
      state = state.copyWith(
        error: 'لا يوجد اتصال بالإنترنت',
        status: AppStatus.error,
      );
      return;
    }

    state = state.copyWith(isLoading: true, error: null);

    try {
      final success = await _authService.login(
        email: email.trim(),
        password: password,
      );

      if (success == true) {
        final user = await _authService.getCurrentUser();
        state = state.copyWith(
          status: AppStatus.authenticated,
          user: user,
          isLoading: false,
          error: null,
        );
      } else {
        state = state.copyWith(
          status: AppStatus.error,
          error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة',
          isLoading: false,
        );
      }
    } catch (e) {
      state = state.copyWith(
        status: AppStatus.error,
        error: 'حدث خطأ أثناء تسجيل الدخول. يرجى المحاولة مرة أخرى',
        isLoading: false,
      );
    }
  }

  Future<void> logout() async {
    if (!state.isConnected) {
      state = state.copyWith(
        error: 'لا يوجد اتصال بالإنترنت',
        status: AppStatus.error,
      );
      return;
    }

    state = state.copyWith(isLoading: true, error: null);

    try {
      await _authService.logout();
      state = state.copyWith(
        status: AppStatus.unauthenticated,
        user: null,
        isLoading: false,
        error: null,
      );
    } catch (e) {
      state = state.copyWith(
        error: 'حدث خطأ أثناء تسجيل الخروج. يرجى المحاولة مرة أخرى',
        status: AppStatus.error,
        isLoading: false,
      );
    }
  }

  void clearError() {
    state = state.copyWith(error: null);
  }
}

final appStateProvider = StateNotifierProvider<AppStateNotifier, AppState>(
  (ref) => AppStateNotifier(
    ref.watch(authServiceProvider),
    ConnectivityService(),
  ),
);
