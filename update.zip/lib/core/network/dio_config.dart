import 'package:dio/dio.dart';
import '../services/storage_service.dart';

class DioConfig {
  final StorageService _storageService;
  final String baseUrl;

  DioConfig(this._storageService, {required this.baseUrl});

  Dio get dio {
    final dio = Dio(
      BaseOptions(
        baseUrl: baseUrl,
        connectTimeout: const Duration(seconds: 30),
        receiveTimeout: const Duration(seconds: 30),
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
      ),
    );

    // إضافة معترض للطلبات
    dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          final token = await _storageService.getToken();
          if (token != null && token.isNotEmpty) {
            options.headers['Authorization'] = 'Bearer $token';
          }
          return handler.next(options);
        },
        onError: (DioException error, handler) async {
          if (error.response?.statusCode == 401) {
            // محاولة تحديث الرمز المميز
            try {
              final refreshed = await _refreshToken();
              if (refreshed) {
                // إعادة المحاولة مع الرمز المميز الجديد
                return handler.resolve(await _retry(error.requestOptions));
              }
            } catch (e) {
              // تسجيل الخروج إذا فشل تحديث الرمز المميز
              await _storageService.remove('token');
            }
          }
          return handler.next(error);
        },
      ),
    );

    return dio;
  }

  Future<bool> _refreshToken() async {
    try {
      final response = await dio.post('/Account/RefreshToken');
      if (response.statusCode == 200 && response.data['token'] != null) {
        await _storageService.setToken(response.data['token']);
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<Response<dynamic>> _retry(RequestOptions requestOptions) async {
    final token = await _storageService.getToken();
    final options = Options(
      method: requestOptions.method,
      headers: {
        ...requestOptions.headers,
        'Authorization': 'Bearer $token',
      },
    );

    return dio.request<dynamic>(
      requestOptions.path,
      data: requestOptions.data,
      queryParameters: requestOptions.queryParameters,
      options: options,
    );
  }
}
