import 'package:dio/dio.dart';
import 'api_response.dart';

class ApiResponseHandler {
  static ApiResponse<T> handleSuccess<T>(
    Response<dynamic> response,
    T Function(Map<String, dynamic>) fromJson,
  ) {
    try {
      if (response.data == null) {
        return ApiResponse<T>(
          success: false,
          message: 'لا توجد بيانات',
        );
      }

      if (response.data is Map<String, dynamic>) {
        final data = fromJson(response.data as Map<String, dynamic>);
        return ApiResponse<T>(
          success: true,
          data: data,
        );
      }

      return ApiResponse<T>(
        success: false,
        message: 'تنسيق البيانات غير صحيح',
      );
    } catch (e) {
      return ApiResponse<T>(
        success: false,
        message: 'خطأ في معالجة البيانات: $e',
      );
    }
  }

  static ApiResponse<T> handleError<T>(dynamic error) {
    if (error is DioException) {
      switch (error.type) {
        case DioExceptionType.connectionTimeout:
        case DioExceptionType.sendTimeout:
        case DioExceptionType.receiveTimeout:
          return ApiResponse<T>(
            success: false,
            message: 'انتهت مهلة الاتصال',
          );

        case DioExceptionType.badResponse:
          final response = error.response;
          final message = response?.data?['message'] ?? 'خطأ في الخادم';
          return ApiResponse<T>(
            success: false,
            message: message,
            statusCode: response?.statusCode,
          );

        case DioExceptionType.cancel:
          return ApiResponse<T>(
            success: false,
            message: 'تم إلغاء الطلب',
          );

        case DioExceptionType.connectionError:
          return ApiResponse<T>(
            success: false,
            message: 'خطأ في الاتصال بالإنترنت',
          );

        default:
          return ApiResponse<T>(
            success: false,
            message: 'حدث خطأ غير متوقع',
          );
      }
    }

    return ApiResponse<T>(
      success: false,
      message: 'حدث خطأ غير معروف',
    );
  }
}
