import 'package:dio/dio.dart' hide Headers;
import 'package:retrofit/retrofit.dart';
import 'package:retrofit/http.dart';
import '../../features/dashboard/domain/models/statistics_model.dart';
import '../../features/orders/domain/models/order_model.dart';
import '../../features/products/domain/models/product_model.dart';
import '../../features/stores/domain/models/store_model.dart';
import '../../features/auth/domain/models/auth_models.dart';
import '../../features/notifications/domain/models/notification_ids_request.dart';
import '../../features/auth/domain/models/merchant_register_response.dart';
import '../../features/auth/domain/models/user_register_response.dart';
import 'api_response.dart';

part 'api_service.g.dart';

@RestApi(baseUrl: "https://localhost:44385/api/v1")
abstract class ApiService {
  factory ApiService(Dio dio,
      {String? baseUrl, ParseErrorLogger? errorLogger}) = _ApiService;

  // تسجيل الدخول
  @POST("/Account/Login")
  Future<ApiResponse<dynamic>> login(@Body() LoginRequest request);

  // تسجيل تاجر جديد
  @POST("/Account/RegisterMerchant")
  Future<ApiResponse<MerchantRegisterResponse>> registerMerchant(
      @Body() MerchantRegisterRequest request);

  // تسجيل مستخدم نهائي جديد
  @POST("/Account/RegisterEndUser")
  Future<ApiResponse<UserRegisterResponse>> registerEndUser(
      @Body() UserRegisterRequest request);

  // تأكيد البريد الإلكتروني
  @POST("/Account/ConfirmEmail")
  Future<ApiResponse<dynamic>> confirmEmail(@Query("token") String token);

  // إعادة إرسال تأكيد البريد الإلكتروني
  @POST("/Account/ResendEmailConfirmation")
  Future<ApiResponse<dynamic>> resendEmailConfirmation(
      @Body() EmailRequest request);

  // نسيان كلمة المرور
  @POST("/Account/ForgotPassword")
  Future<ApiResponse<dynamic>> forgotPassword(@Body() EmailRequest request);

  @POST("/Account/RefreshToken")
  Future<ApiResponse<dynamic>> refreshToken();

  @POST("/Account/Logout")
  Future<ApiResponse<dynamic>> logout();

  // Dashboard Statistics
  @GET("/dashboard/statistics")
  Future<ApiResponse<StatisticsModel>> getDashboardStatistics();

  // Orders
  @GET("/orders")
  Future<ApiResponse<List<OrderModel>>> getOrders({
    @Query("status") String? status,
    @Query("page") int page = 1,
    @Query("limit") int limit = 20,
  });

  @GET("/orders/{id}")
  Future<ApiResponse<OrderModel>> getOrderDetails(@Path("id") String orderId);

  @POST("/orders/{id}/status")
  Future<ApiResponse<dynamic>> updateOrderStatus(
    @Path("id") String orderId,
    @Body() Map<String, dynamic> status,
  );

  // Products
  @GET("/products")
  Future<ApiResponse<List<ProductModel>>> getProducts({
    @Query("category") String? category,
    @Query("page") int page = 1,
    @Query("limit") int limit = 20,
  });

  @GET("/products/{id}")
  Future<ApiResponse<ProductModel>> getProductDetails(
      @Path("id") String productId);

  @POST("/products")
  Future<ApiResponse<ProductModel>> createProduct(@Body() ProductModel product);

  @PUT("/products/{id}")
  Future<ApiResponse<ProductModel>> updateProduct(
    @Path("id") String productId,
    @Body() ProductModel product,
  );

  @DELETE("/products/{id}")
  Future<ApiResponse<dynamic>> deleteProduct(@Path("id") String productId);

  // Stores
  @GET("/stores")
  Future<ApiResponse<List<StoreModel>>> getStores({
    @Query("page") int page = 1,
    @Query("limit") int limit = 20,
  });

  @GET("/stores/{id}")
  Future<ApiResponse<StoreModel>> getStoreDetails(@Path("id") String storeId);

  @POST("/stores")
  Future<ApiResponse<StoreModel>> createStore(@Body() StoreModel store);

  @PUT("/stores/{id}")
  Future<ApiResponse<StoreModel>> updateStore(
    @Path("id") String storeId,
    @Body() StoreModel store,
  );

  @DELETE("/stores/{id}")
  Future<ApiResponse<dynamic>> deleteStore(@Path("id") String storeId);

  // Analytics
  @GET("/analytics/revenue")
  Future<ApiResponse<dynamic>> getRevenueAnalytics({
    @Query("start_date") String? startDate,
    @Query("end_date") String? endDate,
  });

  @GET("/analytics/top-products")
  Future<ApiResponse<dynamic>> getTopProducts({
    @Query("limit") int limit = 10,
    @Query("period") String period = "week",
  });

  @GET("/analytics/top-customers")
  Future<ApiResponse<dynamic>> getTopCustomers({
    @Query("limit") int limit = 10,
    @Query("period") String period = "week",
  });

  // Settings
  @GET("/settings")
  Future<ApiResponse<dynamic>> getSettings();

  @PUT("/settings")
  Future<ApiResponse<dynamic>> updateSettings(
      @Body() Map<String, dynamic> settings);

  // Profile
  @GET("/profile")
  Future<ApiResponse<dynamic>> getProfile();

  @PUT("/profile")
  Future<ApiResponse<dynamic>> updateProfile(
      @Body() Map<String, dynamic> profile);

  // Notifications
  @GET("/notifications")
  Future<ApiResponse<dynamic>> getNotifications({
    @Query("page") int page = 1,
    @Query("limit") int limit = 20,
  });

  @POST("/notifications/mark-read")
  Future<ApiResponse<dynamic>> markNotificationsAsRead(
      @Body() NotificationIdsRequest notificationIds);

  @GET("/weatherforecast")
  Future<ApiResponse<dynamic>> getWeatherForecast();
}
