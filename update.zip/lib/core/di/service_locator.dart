import 'package:get_it/get_it.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:dio/dio.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

import '../network/network_info.dart';
import '../config/app_config.dart';
import '../network/dio_client.dart';
import '../services/storage_service.dart';
import '../network/api_service.dart';
import '../services/auth_service.dart';

import '../../features/auth/data/datasources/auth_remote_datasource.dart';
import '../../features/auth/domain/repositories/auth_repository.dart';
import '../../features/auth/data/repositories/auth_repository_impl.dart';

final getIt = GetIt.instance;

class ServiceLocator {
  static Future<void> init() async {
    // External dependencies
    final sharedPreferences = await SharedPreferences.getInstance();
    getIt.registerSingleton<SharedPreferences>(sharedPreferences);

    final dio = Dio();
    dio.options = BaseOptions(
      baseUrl: AppConfig().apiBaseUrl,
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 30),
      sendTimeout: const Duration(seconds: 30),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    );
    getIt.registerSingleton<Dio>(dio);

    // Core dependencies
    getIt.registerLazySingleton<NetworkInfo>(
        () => NetworkInfoImpl(Connectivity()));
    getIt.registerLazySingleton<DioClient>(
        () => DioClient(dio: getIt<Dio>(), prefs: getIt<SharedPreferences>()));
    getIt.registerLazySingleton<StorageService>(
        () => StorageService(getIt<SharedPreferences>()));
    getIt.registerLazySingleton<ApiService>(() => ApiService(getIt<Dio>()));
    getIt.registerLazySingleton<AuthService>(
        () => AuthService(getIt<ApiService>(), getIt<StorageService>()));

    // Feature: Auth
    // Data sources
    getIt.registerLazySingleton<AuthRemoteDataSource>(
        () => AuthRemoteDataSourceImpl(getIt<Dio>()));

    // Repositories
    getIt.registerLazySingleton<AuthRepository>(() => AuthRepositoryImpl(
          dioClient: getIt<DioClient>(),
          prefs: getIt<SharedPreferences>(),
        ));
  }
}
