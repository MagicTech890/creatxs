import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/auth_service.dart';
import '../services/storage_service.dart';
import '../network/api_service.dart';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../features/auth/domain/models/auth_models.dart';

final sharedPreferencesProvider =
    FutureProvider<SharedPreferences>((ref) async {
  return await SharedPreferences.getInstance();
});

final storageServiceProvider = Provider<StorageService>((ref) {
  final prefs = ref.watch(sharedPreferencesProvider).value;
  if (prefs == null) throw Exception('SharedPreferences not initialized');
  return StorageService(prefs);
});

final authServiceProvider = Provider<AuthService>((ref) {
  final dio = Dio();
  final apiService = ApiService(dio);
  final storageService = ref.watch(storageServiceProvider);
  return AuthService(apiService, storageService);
});

final authStateProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  final authService = ref.watch(authServiceProvider);
  return AuthNotifier(authService);
});

class AuthNotifier extends StateNotifier<AuthState> {
  final AuthService _authService;

  AuthNotifier(this._authService) : super(const AuthState.unauthenticated());

  Future<void> login({required String email, required String password}) async {
    try {
      state = const AuthState.loading();
      final success =
          await _authService.login(email: email, password: password);
      if (success) {
        state = const AuthState.authenticated();
      } else {
        state = const AuthState.error("Login failed");
      }
    } catch (e) {
      state = AuthState.error(e.toString());
    }
  }

  Future<void> registerMerchant({
    required String storeName,
    required String email,
    required String phoneNumber,
    required String password,
  }) async {
    try {
      state = const AuthState.loading();
      await _authService.registerMerchant(
        storeName: storeName,
        email: email,
        phoneNumber: phoneNumber,
        password: password,
      );
      state = const AuthState.authenticated();
    } catch (e) {
      state = AuthState.error(e.toString());
    }
  }

  Future<void> registerEndUser({
    required String email,
    required String phoneNumber,
    required String password,
  }) async {
    try {
      state = const AuthState.loading();
      final request = UserRegisterRequest(
        email: email,
        phoneNumber: phoneNumber,
        password: password,
      );
      await _authService.registerEndUserWithRequest(request);
      state = const AuthState.authenticated();
    } catch (e) {
      state = AuthState.error(e.toString());
    }
  }

  Future<void> logout() async {
    try {
      await _authService.logout();
      state = const AuthState.unauthenticated();
    } catch (e) {
      state = AuthState.error(e.toString());
    }
  }

  Future<void> confirmEmail(String token) async {
    try {
      state = const AuthState.loading();
      final response = await _authService.confirmEmail(token);
      if (response.success) {
        state = const AuthState.unauthenticated();
      } else {
        state =
            AuthState.error(response.message ?? 'فشل تأكيد البريد الإلكتروني');
      }
    } catch (e) {
      state = AuthState.error(e.toString());
    }
  }

  Future<void> resendEmailConfirmation(String email) async {
    try {
      state = const AuthState.loading();
      final response = await _authService.resendEmailConfirmation(email);
      if (response.success) {
        state = const AuthState.unauthenticated();
      } else {
        state = AuthState.error(
            response.message ?? 'فشل إعادة إرسال تأكيد البريد الإلكتروني');
      }
    } catch (e) {
      state = AuthState.error(e.toString());
    }
  }

  Future<void> forgotPassword(String email) async {
    try {
      state = const AuthState.loading();
      final response = await _authService.forgotPassword(email);
      if (response.success) {
        state = const AuthState.unauthenticated();
      } else {
        state = AuthState.error(
            response.message ?? 'فشل إرسال رابط إعادة تعيين كلمة المرور');
      }
    } catch (e) {
      state = AuthState.error(e.toString());
    }
  }
}

class AuthState {
  final bool isAuthenticated;
  final bool isLoading;
  final String? error;

  const AuthState({
    this.isAuthenticated = false,
    this.isLoading = false,
    this.error,
  });

  const AuthState.authenticated()
      : isAuthenticated = true,
        isLoading = false,
        error = null;

  const AuthState.unauthenticated()
      : isAuthenticated = false,
        isLoading = false,
        error = null;

  const AuthState.loading()
      : isAuthenticated = false,
        isLoading = true,
        error = null;

  const AuthState.error(String errorMessage)
      : isAuthenticated = false,
        isLoading = false,
        error = errorMessage;

  AuthState copyWith({
    bool? isAuthenticated,
    bool? isLoading,
    String? error,
  }) {
    return AuthState(
      isAuthenticated: isAuthenticated ?? this.isAuthenticated,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
    );
  }
}
