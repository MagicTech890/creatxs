import 'package:json_annotation/json_annotation.dart';

part 'notification_ids_request.g.dart';

@JsonSerializable()
class NotificationIdsRequest {
  final List<String> ids;

  NotificationIdsRequest({required this.ids});

  factory NotificationIdsRequest.fromJson(Map<String, dynamic> json) =>
      _$NotificationIdsRequestFromJson(json);

  Map<String, dynamic> toJson() => _$NotificationIdsRequestToJson(this);
}
