import 'package:json_annotation/json_annotation.dart';

part 'settings_model.g.dart';

@JsonSerializable()
class SettingsModel {
  final String theme;
  final String language;
  final bool notifications;
  final Map<String, dynamic> preferences;

  SettingsModel({
    required this.theme,
    required this.language,
    required this.notifications,
    required this.preferences,
  });

  factory SettingsModel.fromJson(Map<String, dynamic> json) =>
      _$SettingsModelFromJson(json);

  Map<String, dynamic> toJson() => _$SettingsModelToJson(this);
}
