import 'package:dio/dio.dart';
import '../models/user_model.dart';
import '../models/auth_models.dart';

abstract class AuthRepository {
  /// تسجيل الدخول باستخدام البريد الإلكتروني وكلمة المرور
  Future<UserModel> login({
    required String email,
    required String password,
  });

  /// تسجيل حساب جديد
  Future<UserModel> register({
    required String name,
    required String email,
    required String password,
    String? phone,
  });

  /// تسجيل الخروج
  Future<void> logout();

  /// إعادة تعيين كلمة المرور
  Future<void> resetPassword(String email);

  /// تغيير كلمة المرور
  Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
  });

  /// الحصول على معلومات المستخدم الحالي
  Future<UserModel?> getCurrentUser();

  /// تحديث معلومات المستخدم
  Future<UserModel> updateUserProfile({
    String? name,
    String? phone,
    String? avatar,
  });

  /// التحقق من حالة المصادقة
  Future<bool> isAuthenticated();

  /// الحصول على توكن المصادقة مباشرة
  String? getAuthToken();

  /// تسجيل الدخول باستخدام البريد الإلكتروني (تطبيقات أخرى)
  Future<UserModel> signInWithEmail(String email);

  /// تسجيل الدخول باستخدام حساب Google
  Future<UserModel> signInWithGoogle();

  /// تسجيل الدخول باستخدام حساب Facebook
  Future<UserModel> signInWithFacebook();

  /// تسجيل الدخول باستخدام حساب Apple
  Future<UserModel> signInWithApple();

  /// تسجيل الخروج من الجلسة الحالية
  Future<void> signOut();

  /// تدفق تغييرات حالة المصادقة
  Stream<UserModel?> get authStateChanges;

  Future<AuthResponse> registerMerchant(MerchantRegisterRequest request);
  Future<AuthResponse> registerEndUser(UserRegisterRequest request);
  Future<AuthResponse> loginWithRequest(LoginRequest request);
  Future<AuthResponse> confirmEmail(String token);
  Future<AuthResponse> resendEmailConfirmation(EmailRequest request);
  Future<AuthResponse> forgotPassword(EmailRequest request);
  Future<bool> isLoggedIn();
  Future<String?> getToken();
}
