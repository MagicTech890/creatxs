import 'package:json_annotation/json_annotation.dart';

part 'email_request.g.dart';

@JsonSerializable()
class EmailRequest {
  final String? email;

  EmailRequest({
    this.email,
  });

  factory EmailRequest.fromJson(Map<String, dynamic> json) =>
      _$EmailRequestFromJson(json);

  Map<String, dynamic> toJson() => _$EmailRequestToJson(this);
}
