class UserRegisterRequest {
  final String email;
  final String phoneNumber;
  final String password;

  UserRegisterRequest({
    required this.email,
    required this.phoneNumber,
    required this.password,
  });

  Map<String, dynamic> toJson() {
    return {
      'email': email,
      'phoneNumber': phoneNumber,
      'password': password,
      'confirmPassword': password,
    };
  }

  factory UserRegisterRequest.fromJson(Map<String, dynamic> json) {
    return UserRegisterRequest(
      email: json['email'] as String,
      phoneNumber: json['phoneNumber'] as String,
      password: json['password'] as String,
    );
  }
}
