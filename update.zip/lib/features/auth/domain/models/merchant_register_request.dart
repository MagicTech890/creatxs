class MerchantRegisterRequest {
  final String storeName;
  final String email;
  final String phoneNumber;
  final String password;

  MerchantRegisterRequest({
    required this.storeName,
    required this.email,
    required this.phoneNumber,
    required this.password,
  });

  Map<String, dynamic> toJson() {
    return {
      'storeName': storeName,
      'email': email,
      'phoneNumber': phoneNumber,
      'password': password,
      'confirmPassword': password, // Adding confirmPassword field automatically
    };
  }

  factory MerchantRegisterRequest.fromJson(Map<String, dynamic> json) {
    return MerchantRegisterRequest(
      storeName: json['storeName'] as String,
      email: json['email'] as String,
      phoneNumber: json['phoneNumber'] as String,
      password: json['password'] as String,
    );
  }
}
