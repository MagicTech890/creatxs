import 'package:json_annotation/json_annotation.dart';

part 'user_model.g.dart';

@JsonSerializable()
class UserModel {
  final String id;
  final String email;
  final String? name;
  final String? phoneNumber;
  final String? avatar;
  final DateTime createdAt;
  final bool isEmailConfirmed;
  final String? role;

  UserModel({
    required this.id,
    required this.email,
    this.name,
    this.phoneNumber,
    this.avatar,
    required this.createdAt,
    required this.isEmailConfirmed,
    this.role,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) =>
      _$UserModelFromJson(json);

  Map<String, dynamic> toJson() => _$UserModelToJson(this);

  UserModel copyWith({
    String? id,
    String? email,
    String? name,
    String? phoneNumber,
    String? avatar,
    DateTime? createdAt,
    bool? isEmailConfirmed,
    String? role,
  }) {
    return UserModel(
      id: id ?? this.id,
      email: email ?? this.email,
      name: name ?? this.name,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      avatar: avatar ?? this.avatar,
      createdAt: createdAt ?? this.createdAt,
      isEmailConfirmed: isEmailConfirmed ?? this.isEmailConfirmed,
      role: role ?? this.role,
    );
  }
}
