import 'dart:convert';

class UserModel {
  final String id;
  final String email;
  final String? name;
  final String? phoneNumber;
  final bool isEmailConfirmed;
  final String? token;
  final String? refreshToken;

  UserModel({
    required this.id,
    required this.email,
    this.name,
    this.phoneNumber,
    required this.isEmailConfirmed,
    this.token,
    this.refreshToken,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'name': name,
      'phoneNumber': phoneNumber,
      'isEmailConfirmed': isEmailConfirmed,
      'token': token,
      'refreshToken': refreshToken,
    };
  }

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] as String,
      email: json['email'] as String,
      name: json['name'] as String?,
      phoneNumber: json['phoneNumber'] as String?,
      isEmailConfirmed: json['isEmailConfirmed'] as bool,
      token: json['token'] as String?,
      refreshToken: json['refreshToken'] as String?,
    );
  }

  UserModel copyWith({
    String? id,
    String? email,
    String? name,
    String? phoneNumber,
    bool? isEmailConfirmed,
    String? token,
    String? refreshToken,
  }) {
    return UserModel(
      id: id ?? this.id,
      email: email ?? this.email,
      name: name ?? this.name,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      isEmailConfirmed: isEmailConfirmed ?? this.isEmailConfirmed,
      token: token ?? this.token,
      refreshToken: refreshToken ?? this.refreshToken,
    );
  }
}
