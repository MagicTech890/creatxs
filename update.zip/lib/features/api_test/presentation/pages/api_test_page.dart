import 'package:flutter/material.dart';

class ApiTestPage extends StatelessWidget {
  const ApiTestPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('API Test'),
      ),
      body: const Center(
        child: Text('API Test Page'),
      ),
    );
  }
}
