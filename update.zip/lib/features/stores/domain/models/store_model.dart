import 'package:json_annotation/json_annotation.dart';

part 'store_model.g.dart';

@JsonSerializable()
class StoreModel {
  final String id;
  final String name;
  final String? description;
  final String? logoUrl;
  final String? coverUrl;
  final String ownerId;
  final StoreStatus status;
  final StoreSettings settings;
  final DateTime createdAt;
  final DateTime updatedAt;
  final Map<String, dynamic>? metadata;

  StoreModel({
    required this.id,
    required this.name,
    this.description,
    this.logoUrl,
    this.coverUrl,
    required this.ownerId,
    this.status = StoreStatus.pending,
    required this.settings,
    required this.createdAt,
    required this.updatedAt,
    this.metadata,
  });

  factory StoreModel.fromJson(Map<String, dynamic> json) =>
      _$StoreModelFromJson(json);

  Map<String, dynamic> toJson() => _$StoreModelToJson(this);

  StoreModel copyWith({
    String? id,
    String? name,
    String? description,
    String? logoUrl,
    String? coverUrl,
    String? ownerId,
    StoreStatus? status,
    StoreSettings? settings,
    DateTime? createdAt,
    DateTime? updatedAt,
    Map<String, dynamic>? metadata,
  }) {
    return StoreModel(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      logoUrl: logoUrl ?? this.logoUrl,
      coverUrl: coverUrl ?? this.coverUrl,
      ownerId: ownerId ?? this.ownerId,
      status: status ?? this.status,
      settings: settings ?? this.settings,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      metadata: metadata ?? this.metadata,
    );
  }
}

@JsonSerializable()
class StoreSettings {
  final String currency;
  final String language;
  final String timezone;
  final bool isPublic;
  final bool allowGuestCheckout;
  final List<String> paymentMethods;
  final List<String> shippingMethods;
  final Map<String, dynamic>? customSettings;

  StoreSettings({
    this.currency = 'SAR',
    this.language = 'ar',
    this.timezone = 'Asia/Riyadh',
    this.isPublic = false,
    this.allowGuestCheckout = false,
    this.paymentMethods = const [],
    this.shippingMethods = const [],
    this.customSettings,
  });

  factory StoreSettings.fromJson(Map<String, dynamic> json) =>
      _$StoreSettingsFromJson(json);

  Map<String, dynamic> toJson() => _$StoreSettingsToJson(this);

  StoreSettings copyWith({
    String? currency,
    String? language,
    String? timezone,
    bool? isPublic,
    bool? allowGuestCheckout,
    List<String>? paymentMethods,
    List<String>? shippingMethods,
    Map<String, dynamic>? customSettings,
  }) {
    return StoreSettings(
      currency: currency ?? this.currency,
      language: language ?? this.language,
      timezone: timezone ?? this.timezone,
      isPublic: isPublic ?? this.isPublic,
      allowGuestCheckout: allowGuestCheckout ?? this.allowGuestCheckout,
      paymentMethods: paymentMethods ?? this.paymentMethods,
      shippingMethods: shippingMethods ?? this.shippingMethods,
      customSettings: customSettings ?? this.customSettings,
    );
  }
}

enum StoreStatus {
  @JsonValue('pending')
  pending,
  @JsonValue('active')
  active,
  @JsonValue('suspended')
  suspended,
  @JsonValue('closed')
  closed,
}
