// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'store_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

StoreModel _$StoreModelFromJson(Map<String, dynamic> json) => StoreModel(
      id: json['id'] as String,
      name: json['name'] as String,
      description: json['description'] as String?,
      logoUrl: json['logoUrl'] as String?,
      coverUrl: json['coverUrl'] as String?,
      ownerId: json['ownerId'] as String,
      status: $enumDecodeNullable(_$StoreStatusEnumMap, json['status']) ??
          StoreStatus.pending,
      settings:
          StoreSettings.fromJson(json['settings'] as Map<String, dynamic>),
      createdAt: DateTime.parse(json['createdAt'] as String),
      updatedAt: DateTime.parse(json['updatedAt'] as String),
      metadata: json['metadata'] as Map<String, dynamic>?,
    );

Map<String, dynamic> _$StoreModelToJson(StoreModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'description': instance.description,
      'logoUrl': instance.logoUrl,
      'coverUrl': instance.coverUrl,
      'ownerId': instance.ownerId,
      'status': _$StoreStatusEnumMap[instance.status]!,
      'settings': instance.settings,
      'createdAt': instance.createdAt.toIso8601String(),
      'updatedAt': instance.updatedAt.toIso8601String(),
      'metadata': instance.metadata,
    };

const _$StoreStatusEnumMap = {
  StoreStatus.pending: 'pending',
  StoreStatus.active: 'active',
  StoreStatus.suspended: 'suspended',
  StoreStatus.closed: 'closed',
};

StoreSettings _$StoreSettingsFromJson(Map<String, dynamic> json) =>
    StoreSettings(
      currency: json['currency'] as String? ?? 'SAR',
      language: json['language'] as String? ?? 'ar',
      timezone: json['timezone'] as String? ?? 'Asia/Riyadh',
      isPublic: json['isPublic'] as bool? ?? false,
      allowGuestCheckout: json['allowGuestCheckout'] as bool? ?? false,
      paymentMethods: (json['paymentMethods'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const [],
      shippingMethods: (json['shippingMethods'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const [],
      customSettings: json['customSettings'] as Map<String, dynamic>?,
    );

Map<String, dynamic> _$StoreSettingsToJson(StoreSettings instance) =>
    <String, dynamic>{
      'currency': instance.currency,
      'language': instance.language,
      'timezone': instance.timezone,
      'isPublic': instance.isPublic,
      'allowGuestCheckout': instance.allowGuestCheckout,
      'paymentMethods': instance.paymentMethods,
      'shippingMethods': instance.shippingMethods,
      'customSettings': instance.customSettings,
    };
