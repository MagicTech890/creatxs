import 'package:json_annotation/json_annotation.dart';

part 'weather_forecast_model.g.dart';

@JsonSerializable()
class WeatherForecastModel {
  final DateTime date;
  final int temperatureC;
  final int temperatureF;
  final String summary;

  WeatherForecastModel({
    required this.date,
    required this.temperatureC,
    required this.temperatureF,
    required this.summary,
  });

  factory WeatherForecastModel.fromJson(Map<String, dynamic> json) =>
      _$WeatherForecastModelFromJson(json);

  Map<String, dynamic> toJson() => _$WeatherForecastModelToJson(this);
}
