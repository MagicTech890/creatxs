import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../core/theme/app_theme.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool _isNotificationsEnabled = true;
  bool _isDarkMode = false;
  String _selectedLanguage = 'العربية';
  String _selectedCurrency = 'ريال سعودي (SAR)';
  String _selectedTheme = 'الافتراضي';

  final List<String> _languages = [
    'العربية',
    'English',
  ];

  final List<String> _currencies = [
    'ريال سعودي (SAR)',
    'دولار أمريكي (USD)',
    'يورو (EUR)',
  ];

  final List<String> _themes = [
    'الافتراضي',
    'فاتح',
    'داكن',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            const SizedBox(height: 24),
            _buildStoreSettings(),
            const SizedBox(height: 24),
            _buildAppearanceSettings(),
            const SizedBox(height: 24),
            _buildNotificationSettings(),
            const SizedBox(height: 24),
            _buildSecuritySettings(),
            const SizedBox(height: 24),
            _buildSupportSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppTheme.primaryColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(
            Icons.settings,
            color: AppTheme.primaryColor,
            size: 32,
          ),
        ),
        const SizedBox(width: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'إعدادات المتجر',
              style: GoogleFonts.poppins(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'تخصيص متجرك وتفضيلاتك',
              style: GoogleFonts.poppins(
                fontSize: 14,
                color: Colors.grey,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildStoreSettings() {
    return _buildSettingsCard(
      title: 'إعدادات المتجر',
      icon: Icons.store_outlined,
      children: [
        _buildDropdownSetting(
          label: 'العملة',
          value: _selectedCurrency,
          options: _currencies,
          onChanged: (value) {
            setState(() {
              _selectedCurrency = value!;
            });
          },
        ),
        const SizedBox(height: 16),
        _buildDropdownSetting(
          label: 'اللغة',
          value: _selectedLanguage,
          options: _languages,
          onChanged: (value) {
            setState(() {
              _selectedLanguage = value!;
            });
          },
        ),
        const SizedBox(height: 16),
        _buildTextSetting(
          label: 'المنطقة الزمنية',
          value: 'آسيا/الرياض (GMT+3)',
          icon: Icons.schedule,
          onTap: () {
            // TODO: Open timezone selection
          },
        ),
        const SizedBox(height: 16),
        _buildTextSetting(
          label: 'الضريبة',
          value: '15%',
          icon: Icons.receipt_long_outlined,
          onTap: () {
            // TODO: Open tax settings
          },
        ),
      ],
    );
  }

  Widget _buildAppearanceSettings() {
    return _buildSettingsCard(
      title: 'المظهر',
      icon: Icons.palette_outlined,
      children: [
        _buildDropdownSetting(
          label: 'السمة',
          value: _selectedTheme,
          options: _themes,
          onChanged: (value) {
            setState(() {
              _selectedTheme = value!;
            });
          },
        ),
        const SizedBox(height: 16),
        _buildSwitchSetting(
          label: 'الوضع الداكن',
          value: _isDarkMode,
          onChanged: (value) {
            setState(() {
              _isDarkMode = value;
            });
          },
        ),
        const SizedBox(height: 16),
        _buildTextSetting(
          label: 'شعار المتجر',
          value: 'تغيير الشعار',
          icon: Icons.image_outlined,
          onTap: () {
            // TODO: Open logo uploader
          },
        ),
        const SizedBox(height: 16),
        _buildTextSetting(
          label: 'ألوان المتجر',
          value: 'تخصيص الألوان',
          icon: Icons.color_lens_outlined,
          onTap: () {
            // TODO: Open color picker
          },
        ),
      ],
    );
  }

  Widget _buildNotificationSettings() {
    return _buildSettingsCard(
      title: 'الإشعارات',
      icon: Icons.notifications_outlined,
      children: [
        _buildSwitchSetting(
          label: 'تفعيل الإشعارات',
          value: _isNotificationsEnabled,
          onChanged: (value) {
            setState(() {
              _isNotificationsEnabled = value;
            });
          },
        ),
        const SizedBox(height: 16),
        _buildCheckboxSetting(
          label: 'إشعارات الطلبات الجديدة',
          value: true,
          onChanged: (value) {
            // TODO: Update notification preferences
          },
        ),
        const SizedBox(height: 16),
        _buildCheckboxSetting(
          label: 'إشعارات المنتجات منخفضة المخزون',
          value: true,
          onChanged: (value) {
            // TODO: Update notification preferences
          },
        ),
        const SizedBox(height: 16),
        _buildCheckboxSetting(
          label: 'إشعارات العملاء الجدد',
          value: false,
          onChanged: (value) {
            // TODO: Update notification preferences
          },
        ),
        const SizedBox(height: 16),
        _buildCheckboxSetting(
          label: 'إشعارات البريد الإلكتروني',
          value: true,
          onChanged: (value) {
            // TODO: Update notification preferences
          },
        ),
      ],
    );
  }

  Widget _buildSecuritySettings() {
    return _buildSettingsCard(
      title: 'الأمان',
      icon: Icons.security_outlined,
      children: [
        _buildTextSetting(
          label: 'تغيير كلمة المرور',
          value: '••••••••',
          icon: Icons.lock_outline,
          onTap: () {
            // TODO: Open change password dialog
          },
        ),
        const SizedBox(height: 16),
        _buildSwitchSetting(
          label: 'المصادقة الثنائية',
          value: false,
          onChanged: (value) {
            // TODO: Toggle 2FA
          },
        ),
        const SizedBox(height: 16),
        _buildTextSetting(
          label: 'سجل تسجيل الدخول',
          value: 'عرض السجل',
          icon: Icons.history,
          onTap: () {
            // TODO: Show login history
          },
        ),
        const SizedBox(height: 16),
        _buildTextSetting(
          label: 'تسجيل الخروج من جميع الأجهزة',
          value: 'تسجيل الخروج',
          icon: Icons.logout,
          onTap: () {
            // TODO: Logout from all devices
          },
          color: Colors.red,
        ),
      ],
    );
  }

  Widget _buildSupportSection() {
    return _buildSettingsCard(
      title: 'الدعم والمساعدة',
      icon: Icons.help_outline,
      children: [
        _buildTextSetting(
          label: 'مركز المساعدة',
          value: 'زيارة مركز المساعدة',
          icon: Icons.help_outline,
          onTap: () {
            // TODO: Open help center
          },
        ),
        const SizedBox(height: 16),
        _buildTextSetting(
          label: 'التواصل مع الدعم',
          value: 'فتح تذكرة دعم',
          icon: Icons.support_agent,
          onTap: () {
            // TODO: Open support ticket
          },
        ),
        const SizedBox(height: 16),
        _buildTextSetting(
          label: 'الأسئلة الشائعة',
          value: 'عرض الأسئلة الشائعة',
          icon: Icons.question_answer_outlined,
          onTap: () {
            // TODO: Open FAQs
          },
        ),
        const SizedBox(height: 16),
        _buildTextSetting(
          label: 'الإبلاغ عن مشكلة',
          value: 'إرسال تقرير',
          icon: Icons.bug_report_outlined,
          onTap: () {
            // TODO: Open bug report
          },
        ),
        const SizedBox(height: 24),
        Center(
          child: Text(
            'نسخة التطبيق: 1.0.0',
            style: GoogleFonts.poppins(
              fontSize: 12,
              color: Colors.grey,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSettingsCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              icon,
              color: AppTheme.primaryColor,
              size: 20,
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                spreadRadius: 1,
                blurRadius: 10,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: children,
          ),
        ),
      ],
    );
  }

  Widget _buildDropdownSetting({
    required String label,
    required String value,
    required List<String> options,
    required void Function(String?) onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.poppins(
            fontSize: 14,
            color: Colors.grey.shade600,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: Colors.grey.shade50,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey.shade200),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              isExpanded: true,
              items: options.map((option) {
                return DropdownMenuItem<String>(
                  value: option,
                  child: Text(
                    option,
                    style: GoogleFonts.poppins(
                      fontSize: 14,
                    ),
                  ),
                );
              }).toList(),
              onChanged: onChanged,
              icon: const Icon(Icons.keyboard_arrow_down),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSwitchSetting({
    required String label,
    required bool value,
    required void Function(bool) onChanged,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: GoogleFonts.poppins(
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
          activeColor: AppTheme.primaryColor,
        ),
      ],
    );
  }

  Widget _buildCheckboxSetting({
    required String label,
    required bool value,
    required void Function(bool?) onChanged,
  }) {
    return Row(
      children: [
        Checkbox(
          value: value,
          onChanged: onChanged,
          activeColor: AppTheme.primaryColor,
        ),
        const SizedBox(width: 8),
        Text(
          label,
          style: GoogleFonts.poppins(
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildTextSetting({
    required String label,
    required String value,
    required IconData icon,
    required VoidCallback onTap,
    Color? color,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: GoogleFonts.poppins(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
            Row(
              children: [
                Text(
                  value,
                  style: GoogleFonts.poppins(
                    fontSize: 14,
                    color: color ?? Colors.grey.shade600,
                  ),
                ),
                const SizedBox(width: 8),
                Icon(
                  icon,
                  size: 20,
                  color: color ?? Colors.grey.shade600,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
