import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/routes/app_router.dart';
import '../widgets/top_items_card.dart';
import '../widgets/status_card.dart';
import '../widgets/weekly_chart.dart';
import '../../domain/models/statistics_model.dart';

class DashboardPage extends ConsumerStatefulWidget {
  const DashboardPage({super.key});

  @override
  ConsumerState<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends ConsumerState<DashboardPage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    const _DashboardContent(),
    const Center(child: Text('الطلبات')),
    const Center(child: Text('المنتجات')),
    const Center(child: Text('المتاجر')),
    const Center(child: Text('الملف الشخصي')),
  ];

  void _onItemTapped(int index) {
    switch (index) {
      case 0:
        setState(() => _selectedIndex = index);
        break;
      case 1:
        Navigator.pushNamed(context, AppRouter.orders);
        break;
      case 2:
        Navigator.pushNamed(context, AppRouter.products);
        break;
      case 3:
        Navigator.pushNamed(context, AppRouter.stores);
        break;
      case 4:
        Navigator.pushNamed(context, AppRouter.profile);
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة التحكم'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.pushNamed(context, AppRouter.settings);
            },
          ),
        ],
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: 'لوحة التحكم',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart),
            label: 'الطلبات',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.inventory),
            label: 'المنتجات',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.store),
            label: 'المتاجر',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'الملف الشخصي',
          ),
        ],
      ),
    );
  }
}

class _DashboardContent extends StatelessWidget {
  const _DashboardContent();

  List<DailyStatistics> _getMockData() {
    return [
      DailyStatistics(day: 'الأحد', revenue: 5000, expenses: 3000, orders: 25),
      DailyStatistics(
          day: 'الإثنين', revenue: 6000, expenses: 3500, orders: 30),
      DailyStatistics(
          day: 'الثلاثاء', revenue: 4500, expenses: 2800, orders: 22),
      DailyStatistics(
          day: 'الأربعاء', revenue: 7000, expenses: 4000, orders: 35),
      DailyStatistics(day: 'الخميس', revenue: 8000, expenses: 4500, orders: 40),
      DailyStatistics(day: 'الجمعة', revenue: 3000, expenses: 2000, orders: 15),
      DailyStatistics(day: 'السبت', revenue: 5500, expenses: 3200, orders: 28),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final mockData = _getMockData();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Row(
          children: [
            Expanded(
              child: StatusCard(
                title: 'الطلبات',
                value: '150',
                icon: Icons.shopping_cart,
                color: Colors.blue,
              ),
            ),
            SizedBox(width: 16),
            Expanded(
              child: StatusCard(
                title: 'المنتجات',
                value: '75',
                icon: Icons.inventory,
                color: Colors.green,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        const Row(
          children: [
            Expanded(
              child: StatusCard(
                title: 'المتاجر',
                value: '12',
                icon: Icons.store,
                color: Colors.orange,
              ),
            ),
            SizedBox(width: 16),
            Expanded(
              child: StatusCard(
                title: 'المبيعات',
                value: '₪15,000',
                icon: Icons.attach_money,
                color: Colors.purple,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        WeeklyChart(data: mockData),
        const SizedBox(height: 16),
        const TopItemsCard(
          title: 'أفضل المنتجات مبيعاً',
          items: [
            {'name': 'منتج 1', 'value': '₪5,000'},
            {'name': 'منتج 2', 'value': '₪3,500'},
            {'name': 'منتج 3', 'value': '₪2,800'},
            {'name': 'منتج 4', 'value': '₪2,000'},
            {'name': 'منتج 5', 'value': '₪1,500'},
          ],
        ),
        const SizedBox(height: 16),
        const TopItemsCard(
          title: 'أفضل المتاجر مبيعاً',
          items: [
            {'name': 'متجر 1', 'value': '₪8,000'},
            {'name': 'متجر 2', 'value': '₪6,500'},
            {'name': 'متجر 3', 'value': '₪5,800'},
            {'name': 'متجر 4', 'value': '₪4,000'},
            {'name': 'متجر 5', 'value': '₪3,500'},
          ],
        ),
      ],
    );
  }
}
