import 'package:json_annotation/json_annotation.dart';
import 'statistics_model.dart';

part 'dashboard_data.g.dart';

@JsonSerializable()
class SalesChartData {
  final String date;
  final double amount;
  final int orders;

  SalesChartData({
    required this.date,
    required this.amount,
    required this.orders,
  });

  factory SalesChartData.fromJson(Map<String, dynamic> json) =>
      _$SalesChartDataFromJson(json);

  Map<String, dynamic> toJson() => _$SalesChartDataToJson(this);
}

@JsonSerializable()
class PieChartData {
  final String label;
  final double value;
  final String color;

  PieChartData({
    required this.label,
    required this.value,
    required this.color,
  });

  factory PieChartData.fromJson(Map<String, dynamic> json) =>
      _$PieChartDataFromJson(json);

  Map<String, dynamic> toJson() => _$PieChartDataToJson(this);
}

@JsonSerializable()
class OrderData {
  final String id;
  final String customerName;
  final double amount;
  final String status;
  final DateTime date;

  OrderData({
    required this.id,
    required this.customerName,
    required this.amount,
    required this.status,
    required this.date,
  });

  factory OrderData.fromJson(Map<String, dynamic> json) =>
      _$OrderDataFromJson(json);

  Map<String, dynamic> toJson() => _$OrderDataToJson(this);
}

@JsonSerializable()
class ProductData {
  final String id;
  final String name;
  final double price;
  final int stock;
  final String category;
  final String imageUrl;

  ProductData({
    required this.id,
    required this.name,
    required this.price,
    required this.stock,
    required this.category,
    required this.imageUrl,
  });

  factory ProductData.fromJson(Map<String, dynamic> json) =>
      _$ProductDataFromJson(json);

  Map<String, dynamic> toJson() => _$ProductDataToJson(this);
}

@JsonSerializable()
class DashboardData {
  final StatisticsModel statistics;
  final List<SalesChartData> salesChart;
  final List<PieChartData> pieCharts;
  final List<OrderData> recentOrders;
  final List<ProductData> recentProducts;

  DashboardData({
    required this.statistics,
    required this.salesChart,
    required this.pieCharts,
    required this.recentOrders,
    required this.recentProducts,
  });

  factory DashboardData.fromJson(Map<String, dynamic> json) =>
      _$DashboardDataFromJson(json);

  Map<String, dynamic> toJson() => _$DashboardDataToJson(this);
}
