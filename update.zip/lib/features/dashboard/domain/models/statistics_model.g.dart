// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'statistics_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DailyStatistics _$DailyStatisticsFromJson(Map<String, dynamic> json) =>
    DailyStatistics(
      day: json['day'] as String,
      revenue: (json['revenue'] as num).toDouble(),
      expenses: (json['expenses'] as num).toDouble(),
      orders: (json['orders'] as num).toInt(),
    );

Map<String, dynamic> _$DailyStatisticsToJson(DailyStatistics instance) =>
    <String, dynamic>{
      'day': instance.day,
      'revenue': instance.revenue,
      'expenses': instance.expenses,
      'orders': instance.orders,
    };

StatisticsModel _$StatisticsModelFromJson(Map<String, dynamic> json) =>
    StatisticsModel(
      dailyStats: (json['dailyStats'] as List<dynamic>)
          .map((e) => DailyStatistics.fromJson(e as Map<String, dynamic>))
          .toList(),
      totalRevenue: (json['totalRevenue'] as num).toDouble(),
      totalExpenses: (json['totalExpenses'] as num).toDouble(),
      totalOrders: (json['totalOrders'] as num).toInt(),
      totalProducts: (json['totalProducts'] as num).toInt(),
      totalStores: (json['totalStores'] as num).toInt(),
    );

Map<String, dynamic> _$StatisticsModelToJson(StatisticsModel instance) =>
    <String, dynamic>{
      'dailyStats': instance.dailyStats,
      'totalRevenue': instance.totalRevenue,
      'totalExpenses': instance.totalExpenses,
      'totalOrders': instance.totalOrders,
      'totalProducts': instance.totalProducts,
      'totalStores': instance.totalStores,
    };
