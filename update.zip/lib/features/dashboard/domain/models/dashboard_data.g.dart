// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dashboard_data.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SalesChartData _$SalesChartDataFromJson(Map<String, dynamic> json) =>
    SalesChartData(
      date: json['date'] as String,
      amount: (json['amount'] as num).toDouble(),
      orders: (json['orders'] as num).toInt(),
    );

Map<String, dynamic> _$SalesChartDataToJson(SalesChartData instance) =>
    <String, dynamic>{
      'date': instance.date,
      'amount': instance.amount,
      'orders': instance.orders,
    };

PieChartData _$PieChartDataFromJson(Map<String, dynamic> json) => PieChartData(
      label: json['label'] as String,
      value: (json['value'] as num).toDouble(),
      color: json['color'] as String,
    );

Map<String, dynamic> _$PieChartDataToJson(PieChartData instance) =>
    <String, dynamic>{
      'label': instance.label,
      'value': instance.value,
      'color': instance.color,
    };

OrderData _$OrderDataFromJson(Map<String, dynamic> json) => OrderData(
      id: json['id'] as String,
      customerName: json['customerName'] as String,
      amount: (json['amount'] as num).toDouble(),
      status: json['status'] as String,
      date: DateTime.parse(json['date'] as String),
    );

Map<String, dynamic> _$OrderDataToJson(OrderData instance) => <String, dynamic>{
      'id': instance.id,
      'customerName': instance.customerName,
      'amount': instance.amount,
      'status': instance.status,
      'date': instance.date.toIso8601String(),
    };

ProductData _$ProductDataFromJson(Map<String, dynamic> json) => ProductData(
      id: json['id'] as String,
      name: json['name'] as String,
      price: (json['price'] as num).toDouble(),
      stock: (json['stock'] as num).toInt(),
      category: json['category'] as String,
      imageUrl: json['imageUrl'] as String,
    );

Map<String, dynamic> _$ProductDataToJson(ProductData instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'price': instance.price,
      'stock': instance.stock,
      'category': instance.category,
      'imageUrl': instance.imageUrl,
    };

DashboardData _$DashboardDataFromJson(Map<String, dynamic> json) =>
    DashboardData(
      statistics:
          StatisticsModel.fromJson(json['statistics'] as Map<String, dynamic>),
      salesChart: (json['salesChart'] as List<dynamic>)
          .map((e) => SalesChartData.fromJson(e as Map<String, dynamic>))
          .toList(),
      pieCharts: (json['pieCharts'] as List<dynamic>)
          .map((e) => PieChartData.fromJson(e as Map<String, dynamic>))
          .toList(),
      recentOrders: (json['recentOrders'] as List<dynamic>)
          .map((e) => OrderData.fromJson(e as Map<String, dynamic>))
          .toList(),
      recentProducts: (json['recentProducts'] as List<dynamic>)
          .map((e) => ProductData.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$DashboardDataToJson(DashboardData instance) =>
    <String, dynamic>{
      'statistics': instance.statistics,
      'salesChart': instance.salesChart,
      'pieCharts': instance.pieCharts,
      'recentOrders': instance.recentOrders,
      'recentProducts': instance.recentProducts,
    };
