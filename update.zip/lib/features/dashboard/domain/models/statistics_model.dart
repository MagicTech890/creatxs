import 'package:json_annotation/json_annotation.dart';

part 'statistics_model.g.dart';

@JsonSerializable()
class DailyStatistics {
  final String day;
  final double revenue;
  final double expenses;
  final int orders;

  DailyStatistics({
    required this.day,
    required this.revenue,
    required this.expenses,
    required this.orders,
  });

  factory DailyStatistics.fromJson(Map<String, dynamic> json) =>
      _$DailyStatisticsFromJson(json);

  Map<String, dynamic> toJson() => _$DailyStatisticsToJson(this);

  double get profit => revenue - expenses;
  double get profitMargin => revenue > 0 ? (profit / revenue) * 100 : 0;
}

@JsonSerializable()
class StatisticsModel {
  final List<DailyStatistics> dailyStats;
  final double totalRevenue;
  final double totalExpenses;
  final int totalOrders;
  final int totalProducts;
  final int totalStores;

  StatisticsModel({
    required this.dailyStats,
    required this.totalRevenue,
    required this.totalExpenses,
    required this.totalOrders,
    required this.totalProducts,
    required this.totalStores,
  });

  factory StatisticsModel.fromJson(Map<String, dynamic> json) =>
      _$StatisticsModelFromJson(json);

  Map<String, dynamic> toJson() => _$StatisticsModelToJson(this);

  double get totalProfit => totalRevenue - totalExpenses;
  double get totalProfitMargin =>
      totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;
}

class MonthlyStatistics {
  final String month;
  final double revenue;
  final double expenses;
  final int ordersCount;
  final int customersCount;

  MonthlyStatistics({
    required this.month,
    required this.revenue,
    required this.expenses,
    required this.ordersCount,
    required this.customersCount,
  });

  double get profit => revenue - expenses;
  double get profitMargin => revenue > 0 ? (profit / revenue) * 100 : 0;
  double get averageOrderValue => ordersCount > 0 ? revenue / ordersCount : 0;
}

class SalesDistribution {
  final String category;
  final double value;
  final double percentage;

  SalesDistribution({
    required this.category,
    required this.value,
    required this.percentage,
  });
}

class PerformanceMetrics {
  final double conversionRate;
  final double cartAbandonmentRate;
  final double averageOrderValue;
  final double customerRetentionRate;

  PerformanceMetrics({
    required this.conversionRate,
    required this.cartAbandonmentRate,
    required this.averageOrderValue,
    required this.customerRetentionRate,
  });
}
