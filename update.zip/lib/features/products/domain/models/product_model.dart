import 'package:json_annotation/json_annotation.dart';

part 'product_model.g.dart';

@JsonSerializable()
class ProductModel {
  final String id;
  final String storeId;
  final String name;
  final String? description;
  final double price;
  final double? compareAtPrice;
  final int quantity;
  final String sku;
  final String? barcode;
  final List<String> images;
  final List<String> categories;
  final List<String> tags;
  final Map<String, dynamic> options;
  final Map<String, dynamic> variants;
  final ProductStatus status;
  final DateTime createdAt;
  final DateTime updatedAt;
  final Map<String, dynamic>? metadata;

  ProductModel({
    required this.id,
    required this.storeId,
    required this.name,
    this.description,
    required this.price,
    this.compareAtPrice,
    required this.quantity,
    required this.sku,
    this.barcode,
    this.images = const [],
    this.categories = const [],
    this.tags = const [],
    this.options = const {},
    this.variants = const {},
    this.status = ProductStatus.draft,
    required this.createdAt,
    required this.updatedAt,
    this.metadata,
  });

  factory ProductModel.fromJson(Map<String, dynamic> json) =>
      _$ProductModelFromJson(json);

  Map<String, dynamic> toJson() => _$ProductModelToJson(this);

  ProductModel copyWith({
    String? id,
    String? storeId,
    String? name,
    String? description,
    double? price,
    double? compareAtPrice,
    int? quantity,
    String? sku,
    String? barcode,
    List<String>? images,
    List<String>? categories,
    List<String>? tags,
    Map<String, dynamic>? options,
    Map<String, dynamic>? variants,
    ProductStatus? status,
    DateTime? createdAt,
    DateTime? updatedAt,
    Map<String, dynamic>? metadata,
  }) {
    return ProductModel(
      id: id ?? this.id,
      storeId: storeId ?? this.storeId,
      name: name ?? this.name,
      description: description ?? this.description,
      price: price ?? this.price,
      compareAtPrice: compareAtPrice ?? this.compareAtPrice,
      quantity: quantity ?? this.quantity,
      sku: sku ?? this.sku,
      barcode: barcode ?? this.barcode,
      images: images ?? this.images,
      categories: categories ?? this.categories,
      tags: tags ?? this.tags,
      options: options ?? this.options,
      variants: variants ?? this.variants,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      metadata: metadata ?? this.metadata,
    );
  }

  double get discountPercentage {
    if (compareAtPrice == null || compareAtPrice! <= price) {
      return 0;
    }
    return ((compareAtPrice! - price) / compareAtPrice!) * 100;
  }

  bool get isOnSale => compareAtPrice != null && compareAtPrice! > price;
  bool get isInStock => quantity > 0;
  bool get isPublished => status == ProductStatus.active;
}

enum ProductStatus {
  @JsonValue('draft')
  draft,
  @JsonValue('active')
  active,
  @JsonValue('archived')
  archived,
}
