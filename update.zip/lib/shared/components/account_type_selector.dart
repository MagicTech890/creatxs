import 'package:flutter/material.dart';

class AccountTypeSelector extends StatelessWidget {
  final String selectedType;
  final Function(String) onChanged;
  const AccountTypeSelector(
      {Key? key, required this.selectedType, required this.onChanged})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: RadioListTile<String>(
            title: Text('Merchant'),
            value: 'merchant',
            groupValue: selectedType,
            onChanged: (value) => onChanged(value!),
          ),
        ),
        Expanded(
          child: RadioListTile<String>(
            title: Text('User'),
            value: 'user',
            groupValue: selectedType,
            onChanged: (value) => onChanged(value!),
          ),
        ),
      ],
    );
  }
}
